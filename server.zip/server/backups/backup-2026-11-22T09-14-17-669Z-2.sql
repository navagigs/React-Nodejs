-- Admin React MySQL Backup
-- Generated at: 2026-11-22T09:14:17.673Z
-- Database: admin_react

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `app_settings`;
CREATE TABLE `app_settings` (
  `id` int(11) NOT NULL,
  `site_title` varchar(150) NOT NULL DEFAULT 'Admin Panel',
  `site_description` varchar(500) NOT NULL DEFAULT '',
  `logo` varchar(255) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` varchar(500) DEFAULT NULL,
  `meta_keywords` varchar(500) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `digital_signature` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `app_settings` (`id`, `site_title`, `site_description`, `logo`, `meta_title`, `meta_description`, `meta_keywords`, `updated_at`, `digital_signature`) VALUES (1, 'Dashboard', 'PT Crop Inspirasi Digital', '1795226262184_14ce5795.png', 'PT Crop Inspirasi Digital', 'PT Crop Inspirasi Digital', 'admin, dashboard, react', '2026-11-22 11:08:42', '1795244960183_eca2f0c7.jpeg');

DROP TABLE IF EXISTS `articles`;
CREATE TABLE `articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` enum('published','draft') DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `articles_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `articles` (`id`, `title`, `content`, `image`, `status`, `category_id`, `created_at`, `updated_at`) VALUES (1, 'test', '<p>test</p>', '1787749199003.jpeg', 'published', 4, '2026-08-26 19:59:59', '2026-08-26 21:03:16');

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `categories` (`id`, `name`, `created_at`) VALUES (1, 'Teknologir', '2025-12-25 21:36:13');
INSERT INTO `categories` (`id`, `name`, `created_at`) VALUES (2, 'Bisnis', '2025-12-25 21:36:13');
INSERT INTO `categories` (`id`, `name`, `created_at`) VALUES (4, 'Lingkungan', '2025-12-25 21:36:13');
INSERT INTO `categories` (`id`, `name`, `created_at`) VALUES (5, 'Olahraga', '2025-12-25 21:36:13');

DROP TABLE IF EXISTS `client`;
CREATE TABLE `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `client` (`id`, `name`, `address`, `created_at`, `image`) VALUES (1, 'Dana Pensiun Telkom', 'Jl. Surapati No. 151 Bandung', '2025-12-25 20:46:59', '1780850508083.png');

DROP TABLE IF EXISTS `fin_accounts`;
CREATE TABLE `fin_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_group` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sub_group` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `normal_balance` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'debit',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_fin_account_code` (`code`),
  KEY `idx_fin_account_group` (`account_group`)
) ENGINE=InnoDB AUTO_INCREMENT=18987 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `fin_accounts` (`id`, `code`, `name`, `account_group`, `sub_group`, `normal_balance`, `is_active`, `created_at`) VALUES (1, '101', 'Kas', 'asset', 'Kas', 'debit', 1, '2026-11-22 14:22:02');
INSERT INTO `fin_accounts` (`id`, `code`, `name`, `account_group`, `sub_group`, `normal_balance`, `is_active`, `created_at`) VALUES (2, '102', 'Bank', 'asset', 'Bank', 'debit', 1, '2026-11-22 14:22:02');
INSERT INTO `fin_accounts` (`id`, `code`, `name`, `account_group`, `sub_group`, `normal_balance`, `is_active`, `created_at`) VALUES (3, '110', 'Piutang usaha', 'asset', 'Piutang', 'debit', 1, '2026-11-22 14:22:02');
INSERT INTO `fin_accounts` (`id`, `code`, `name`, `account_group`, `sub_group`, `normal_balance`, `is_active`, `created_at`) VALUES (4, '120', 'Persediaan', 'asset', 'Persediaan', 'debit', 1, '2026-11-22 14:22:02');
INSERT INTO `fin_accounts` (`id`, `code`, `name`, `account_group`, `sub_group`, `normal_balance`, `is_active`, `created_at`) VALUES (5, '130', 'Aset tetap', 'asset', 'Aset tetap', 'debit', 1, '2026-11-22 14:22:02');
INSERT INTO `fin_accounts` (`id`, `code`, `name`, `account_group`, `sub_group`, `normal_balance`, `is_active`, `created_at`) VALUES (6, '135', 'Akumulasi penyusutan', 'asset', 'Aset tetap', 'credit', 1, '2026-11-22 14:22:02');
INSERT INTO `fin_accounts` (`id`, `code`, `name`, `account_group`, `sub_group`, `normal_balance`, `is_active`, `created_at`) VALUES (7, '201', 'Utang usaha', 'liability', 'Utang', 'credit', 1, '2026-11-22 14:22:02');
INSERT INTO `fin_accounts` (`id`, `code`, `name`, `account_group`, `sub_group`, `normal_balance`, `is_active`, `created_at`) VALUES (8, '202', 'Utang gaji', 'liability', 'Utang', 'credit', 1, '2026-11-22 14:22:02');
INSERT INTO `fin_accounts` (`id`, `code`, `name`, `account_group`, `sub_group`, `normal_balance`, `is_active`, `created_at`) VALUES (9, '203', 'Utang pajak', 'liability', 'Utang', 'credit', 1, '2026-11-22 14:22:02');
INSERT INTO `fin_accounts` (`id`, `code`, `name`, `account_group`, `sub_group`, `normal_balance`, `is_active`, `created_at`) VALUES (10, '209', 'Kewajiban lainnya', 'liability', 'Utang', 'credit', 1, '2026-11-22 14:22:02');
INSERT INTO `fin_accounts` (`id`, `code`, `name`, `account_group`, `sub_group`, `normal_balance`, `is_active`, `created_at`) VALUES (11, '301', 'Modal perusahaan', 'equity', 'Modal', 'credit', 1, '2026-11-22 14:22:02');
INSERT INTO `fin_accounts` (`id`, `code`, `name`, `account_group`, `sub_group`, `normal_balance`, `is_active`, `created_at`) VALUES (12, '310', 'Saldo laba', 'equity', 'Modal', 'credit', 1, '2026-11-22 14:22:02');
INSERT INTO `fin_accounts` (`id`, `code`, `name`, `account_group`, `sub_group`, `normal_balance`, `is_active`, `created_at`) VALUES (13, '320', 'Laba tahun berjalan', 'equity', 'Modal', 'credit', 1, '2026-11-22 14:22:02');
INSERT INTO `fin_accounts` (`id`, `code`, `name`, `account_group`, `sub_group`, `normal_balance`, `is_active`, `created_at`) VALUES (14, '401', 'Pendapatan usaha', 'revenue', 'Pendapatan', 'credit', 1, '2026-11-22 14:22:02');
INSERT INTO `fin_accounts` (`id`, `code`, `name`, `account_group`, `sub_group`, `normal_balance`, `is_active`, `created_at`) VALUES (15, '402', 'Pendapatan jasa', 'revenue', 'Pendapatan', 'credit', 1, '2026-11-22 14:22:02');
INSERT INTO `fin_accounts` (`id`, `code`, `name`, `account_group`, `sub_group`, `normal_balance`, `is_active`, `created_at`) VALUES (16, '403', 'Pendapatan lainnya', 'revenue', 'Pendapatan', 'credit', 1, '2026-11-22 14:22:02');
INSERT INTO `fin_accounts` (`id`, `code`, `name`, `account_group`, `sub_group`, `normal_balance`, `is_active`, `created_at`) VALUES (17, '501', 'Beban gaji', 'expense', 'Beban', 'debit', 1, '2026-11-22 14:22:02');
INSERT INTO `fin_accounts` (`id`, `code`, `name`, `account_group`, `sub_group`, `normal_balance`, `is_active`, `created_at`) VALUES (18, '502', 'Beban operasional', 'expense', 'Beban', 'debit', 1, '2026-11-22 14:22:02');
INSERT INTO `fin_accounts` (`id`, `code`, `name`, `account_group`, `sub_group`, `normal_balance`, `is_active`, `created_at`) VALUES (19, '503', 'Beban pemasaran', 'expense', 'Beban', 'debit', 1, '2026-11-22 14:22:02');
INSERT INTO `fin_accounts` (`id`, `code`, `name`, `account_group`, `sub_group`, `normal_balance`, `is_active`, `created_at`) VALUES (20, '504', 'Beban penyusutan', 'expense', 'Beban', 'debit', 1, '2026-11-22 14:22:02');
INSERT INTO `fin_accounts` (`id`, `code`, `name`, `account_group`, `sub_group`, `normal_balance`, `is_active`, `created_at`) VALUES (21, '505', 'Beban pajak', 'expense', 'Beban', 'debit', 1, '2026-11-22 14:22:02');
INSERT INTO `fin_accounts` (`id`, `code`, `name`, `account_group`, `sub_group`, `normal_balance`, `is_active`, `created_at`) VALUES (22, '509', 'Beban lainnya', 'expense', 'Beban', 'debit', 1, '2026-11-22 14:22:02');

DROP TABLE IF EXISTS `fin_approvals`;
CREATE TABLE `fin_approvals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entity_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_id` int(11) NOT NULL,
  `action` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'approve',
  `approver_id` int(11) DEFAULT NULL,
  `approver_name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approver_role` int(11) DEFAULT NULL,
  `note` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fin_approval_entity` (`entity_type`,`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `fin_asset_depreciations`;
CREATE TABLE `fin_asset_depreciations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) NOT NULL,
  `period` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `accumulated_after` decimal(18,2) NOT NULL,
  `book_value_after` decimal(18,2) NOT NULL,
  `journal_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_fin_depreciation` (`asset_id`,`period`),
  CONSTRAINT `fk_fin_depreciation_asset` FOREIGN KEY (`asset_id`) REFERENCES `fin_assets` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `fin_assets`;
CREATE TABLE `fin_assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_code` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `purchase_date` date NOT NULL,
  `cost` decimal(18,2) NOT NULL,
  `useful_life_months` int(11) NOT NULL DEFAULT '12',
  `residual_value` decimal(18,2) NOT NULL DEFAULT '0.00',
  `depreciation_method` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'straight_line',
  `accumulated_depreciation` decimal(18,2) NOT NULL DEFAULT '0.00',
  `book_value` decimal(18,2) NOT NULL DEFAULT '0.00',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `account_id` int(11) DEFAULT NULL,
  `journal_id` int(11) DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_fin_asset_code` (`asset_code`),
  KEY `idx_fin_asset_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `fin_audit_logs`;
CREATE TABLE `fin_audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entity_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `action` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `old_values` text COLLATE utf8mb4_unicode_ci,
  `new_values` text COLLATE utf8mb4_unicode_ci,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `ip_address` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fin_audit_entity` (`entity_type`,`entity_id`),
  KEY `idx_fin_audit_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `fin_budgets`;
CREATE TABLE `fin_budgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `budget_year` smallint(6) NOT NULL,
  `budget_month` tinyint(4) NOT NULL DEFAULT '0',
  `amount` decimal(18,2) NOT NULL DEFAULT '0.00',
  `warning_threshold` decimal(5,2) NOT NULL DEFAULT '80.00',
  `notes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_fin_budget` (`category`,`budget_year`,`budget_month`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `fin_cash_accounts`;
CREATE TABLE `fin_cash_accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_number` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner_name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'bank',
  `coa_code` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '101',
  `opening_balance` decimal(18,2) NOT NULL DEFAULT '0.00',
  `current_balance` decimal(18,2) NOT NULL DEFAULT '0.00',
  `currency` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'IDR',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_fin_cash_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `fin_cash_movements`;
CREATE TABLE `fin_cash_movements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `movement_date` date NOT NULL,
  `movement_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `direction` tinyint(1) NOT NULL,
  `balance_after` decimal(18,2) NOT NULL DEFAULT '0.00',
  `reference_type` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_id` int(11) DEFAULT NULL,
  `transfer_id` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fin_cash_movement_account` (`account_id`,`movement_date`),
  KEY `idx_fin_cash_movement_ref` (`reference_type`,`reference_id`),
  KEY `idx_fin_cash_movement_transfer` (`transfer_id`),
  CONSTRAINT `fk_fin_cash_movement_account` FOREIGN KEY (`account_id`) REFERENCES `fin_cash_accounts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `fin_debt_payments`;
CREATE TABLE `fin_debt_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `debt_id` int(11) NOT NULL,
  `payment_date` date NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `account_id` int(11) NOT NULL,
  `proof_file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `journal_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fin_debt_payment_debt` (`debt_id`),
  CONSTRAINT `fk_fin_debt_payment_debt` FOREIGN KEY (`debt_id`) REFERENCES `fin_debts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `fin_debts`;
CREATE TABLE `fin_debts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_no` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creditor_name` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `debt_date` date NOT NULL,
  `due_date` date NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `paid_amount` decimal(18,2) NOT NULL DEFAULT '0.00',
  `remaining` decimal(18,2) NOT NULL DEFAULT '0.00',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unpaid',
  `description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `journal_id` int(11) DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_fin_debt_no` (`transaction_no`),
  KEY `idx_fin_debt_due` (`due_date`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `fin_employee_salaries`;
CREATE TABLE `fin_employee_salaries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_id` int(11) NOT NULL,
  `base_salary` decimal(18,2) NOT NULL DEFAULT '0.00',
  `allowance_position` decimal(18,2) NOT NULL DEFAULT '0.00',
  `allowance_transport` decimal(18,2) NOT NULL DEFAULT '0.00',
  `allowance_meal` decimal(18,2) NOT NULL DEFAULT '0.00',
  `allowance_other` decimal(18,2) NOT NULL DEFAULT '0.00',
  `bpjs_health` decimal(18,2) NOT NULL DEFAULT '0.00',
  `bpjs_employment` decimal(18,2) NOT NULL DEFAULT '0.00',
  `pph21` decimal(18,2) NOT NULL DEFAULT '0.00',
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_fin_employee_salary` (`employee_id`),
  CONSTRAINT `fk_fin_salary_employee` FOREIGN KEY (`employee_id`) REFERENCES `fin_employees` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `fin_employees`;
CREATE TABLE `fin_employees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_code` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_name` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_account` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `join_date` date DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_fin_employee_code` (`employee_code`),
  KEY `idx_fin_employee_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `fin_expenses`;
CREATE TABLE `fin_expenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_no` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `external_ref` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_date` date NOT NULL,
  `category` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vendor_name` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(18,2) NOT NULL,
  `payment_method` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'transfer',
  `account_id` int(11) DEFAULT NULL,
  `invoice_no` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `proof_file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'paid',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `journal_id` int(11) DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `cancelled_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_fin_expense_no` (`transaction_no`),
  UNIQUE KEY `uniq_fin_expense_ref` (`external_ref`),
  KEY `idx_fin_expense_date_status` (`transaction_date`,`status`),
  KEY `idx_fin_expense_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `fin_fiscal_periods`;
CREATE TABLE `fin_fiscal_periods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `period` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `closed_by` int(11) DEFAULT NULL,
  `closed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_fin_fiscal_period` (`period`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `fin_incomes`;
CREATE TABLE `fin_incomes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_no` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `external_ref` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_date` date NOT NULL,
  `category` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_name` varchar(180) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(18,2) NOT NULL,
  `payment_method` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'transfer',
  `account_id` int(11) DEFAULT NULL,
  `invoice_no` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `proof_file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'paid',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `journal_id` int(11) DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `cancelled_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_fin_income_no` (`transaction_no`),
  UNIQUE KEY `uniq_fin_income_ref` (`external_ref`),
  KEY `idx_fin_income_date_status` (`transaction_date`,`status`),
  KEY `idx_fin_income_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `fin_journal_lines`;
CREATE TABLE `fin_journal_lines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `journal_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `debit` decimal(18,2) NOT NULL DEFAULT '0.00',
  `credit` decimal(18,2) NOT NULL DEFAULT '0.00',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `line_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fin_journal_line_journal` (`journal_id`),
  KEY `idx_fin_journal_line_account` (`account_id`),
  CONSTRAINT `fk_fin_journal_line_account` FOREIGN KEY (`account_id`) REFERENCES `fin_accounts` (`id`),
  CONSTRAINT `fk_fin_journal_line_journal` FOREIGN KEY (`journal_id`) REFERENCES `fin_journals` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `fin_journals`;
CREATE TABLE `fin_journals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `journal_no` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `journal_date` date NOT NULL,
  `description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_type` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_id` int(11) DEFAULT NULL,
  `total_debit` decimal(18,2) NOT NULL DEFAULT '0.00',
  `total_credit` decimal(18,2) NOT NULL DEFAULT '0.00',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'posted',
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `cancelled_by` int(11) DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `cancelled_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reversal_of` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_fin_journal_no` (`journal_no`),
  KEY `idx_fin_journal_date` (`journal_date`,`status`),
  KEY `idx_fin_journal_ref` (`reference_type`,`reference_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `fin_notifications`;
CREATE TABLE `fin_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_type` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_id` int(11) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fin_notification_user` (`user_id`,`is_read`),
  KEY `idx_fin_notification_due` (`due_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `fin_payroll_adjustments`;
CREATE TABLE `fin_payroll_adjustments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payroll_record_id` int(11) NOT NULL,
  `field_name` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `old_value` decimal(18,2) NOT NULL DEFAULT '0.00',
  `new_value` decimal(18,2) NOT NULL DEFAULT '0.00',
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `changed_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fin_payroll_adjustment_record` (`payroll_record_id`),
  CONSTRAINT `fk_fin_payroll_adjustment_record` FOREIGN KEY (`payroll_record_id`) REFERENCES `fin_payroll_records` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `fin_payroll_components`;
CREATE TABLE `fin_payroll_components` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `component_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `calculation` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fixed',
  `default_amount` decimal(18,2) NOT NULL DEFAULT '0.00',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_fin_payroll_component` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `fin_payroll_periods`;
CREATE TABLE `fin_payroll_periods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `period` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `pay_date` date DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `department` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `paid_by` int(11) DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `journal_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_fin_payroll_period` (`period`,`department`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `fin_payroll_records`;
CREATE TABLE `fin_payroll_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `period_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `employee_code` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `employee_name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_salary` decimal(18,2) NOT NULL DEFAULT '0.00',
  `allowance_position` decimal(18,2) NOT NULL DEFAULT '0.00',
  `allowance_transport` decimal(18,2) NOT NULL DEFAULT '0.00',
  `allowance_meal` decimal(18,2) NOT NULL DEFAULT '0.00',
  `allowance_other` decimal(18,2) NOT NULL DEFAULT '0.00',
  `bonus` decimal(18,2) NOT NULL DEFAULT '0.00',
  `overtime` decimal(18,2) NOT NULL DEFAULT '0.00',
  `deduction_late` decimal(18,2) NOT NULL DEFAULT '0.00',
  `deduction_loan` decimal(18,2) NOT NULL DEFAULT '0.00',
  `bpjs_health` decimal(18,2) NOT NULL DEFAULT '0.00',
  `bpjs_employment` decimal(18,2) NOT NULL DEFAULT '0.00',
  `pph21` decimal(18,2) NOT NULL DEFAULT '0.00',
  `deduction_other` decimal(18,2) NOT NULL DEFAULT '0.00',
  `total_income` decimal(18,2) NOT NULL DEFAULT '0.00',
  `total_deduction` decimal(18,2) NOT NULL DEFAULT '0.00',
  `net_pay` decimal(18,2) NOT NULL DEFAULT '0.00',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `payment_reference` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_fin_payroll_record` (`period_id`,`employee_id`),
  KEY `idx_fin_payroll_record_status` (`status`),
  KEY `fk_fin_payroll_record_employee` (`employee_id`),
  CONSTRAINT `fk_fin_payroll_record_employee` FOREIGN KEY (`employee_id`) REFERENCES `fin_employees` (`id`),
  CONSTRAINT `fk_fin_payroll_record_period` FOREIGN KEY (`period_id`) REFERENCES `fin_payroll_periods` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `fin_receivable_payments`;
CREATE TABLE `fin_receivable_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receivable_id` int(11) NOT NULL,
  `payment_date` date NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `account_id` int(11) NOT NULL,
  `proof_file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `journal_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fin_receivable_payment_parent` (`receivable_id`),
  CONSTRAINT `fk_fin_receivable_payment_parent` FOREIGN KEY (`receivable_id`) REFERENCES `fin_receivables` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `fin_receivables`;
CREATE TABLE `fin_receivables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_no` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_name` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoice_date` date NOT NULL,
  `due_date` date NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `received_amount` decimal(18,2) NOT NULL DEFAULT '0.00',
  `remaining` decimal(18,2) NOT NULL DEFAULT '0.00',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unpaid',
  `description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `journal_id` int(11) DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_fin_receivable_invoice` (`invoice_no`),
  KEY `idx_fin_receivable_due` (`due_date`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `fin_sequences`;
CREATE TABLE `fin_sequences` (
  `seq_key` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seq_value` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`seq_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `fin_sequences` (`seq_key`, `seq_value`) VALUES ('GAJ202611', 1);
INSERT INTO `fin_sequences` (`seq_key`, `seq_value`) VALUES ('JRU202611', 16);
INSERT INTO `fin_sequences` (`seq_key`, `seq_value`) VALUES ('PMA202611', 2);
INSERT INTO `fin_sequences` (`seq_key`, `seq_value`) VALUES ('PMK202611', 1);
INSERT INTO `fin_sequences` (`seq_key`, `seq_value`) VALUES ('TRF202611', 1);
INSERT INTO `fin_sequences` (`seq_key`, `seq_value`) VALUES ('UTG202611', 1);

DROP TABLE IF EXISTS `fin_settings`;
CREATE TABLE `fin_settings` (
  `setting_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `setting_value` text COLLATE utf8mb4_unicode_ci,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `fin_settings` (`setting_key`, `setting_value`, `updated_by`, `updated_at`) VALUES ('approval_limit', '10000000', NULL, '2026-11-22 14:22:02');
INSERT INTO `fin_settings` (`setting_key`, `setting_value`, `updated_by`, `updated_at`) VALUES ('approver_roles', '[1,7,8,9]', NULL, '2026-11-22 14:22:02');
INSERT INTO `fin_settings` (`setting_key`, `setting_value`, `updated_by`, `updated_at`) VALUES ('company_name', 'Perusahaan', NULL, '2026-11-22 14:22:02');
INSERT INTO `fin_settings` (`setting_key`, `setting_value`, `updated_by`, `updated_at`) VALUES ('currency', 'IDR', NULL, '2026-11-22 14:22:02');
INSERT INTO `fin_settings` (`setting_key`, `setting_value`, `updated_by`, `updated_at`) VALUES ('expense_coa_map', '{"gaji_dan_tunjangan":"501","operasional_kantor":"502","internet_telekomunikasi":"502","sewa_kantor":"502","listrik_air":"502","transportasi_perjalanan":"502","konsumsi_kantor":"502","pembelian_aset":"130","pemasaran":"503","biaya_proyek":"502","pajak_administrasi":"505","langganan_software":"502","pemeliharaan":"502","pengeluaran_lainnya":"509"}', NULL, '2026-11-22 14:22:02');
INSERT INTO `fin_settings` (`setting_key`, `setting_value`, `updated_by`, `updated_at`) VALUES ('income_coa_map', '{"pendapatan_proyek":"401","pendapatan_jasa":"402","pendapatan_penjualan":"401","pendapatan_langganan":"401","pendapatan_investasi":"403","pendapatan_lainnya":"403"}', NULL, '2026-11-22 14:22:02');
INSERT INTO `fin_settings` (`setting_key`, `setting_value`, `updated_by`, `updated_at`) VALUES ('payroll_pay_day', '25', NULL, '2026-11-22 14:22:02');
INSERT INTO `fin_settings` (`setting_key`, `setting_value`, `updated_by`, `updated_at`) VALUES ('reminder_days', '7', NULL, '2026-11-22 14:22:02');

DROP TABLE IF EXISTS `fin_transfers`;
CREATE TABLE `fin_transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_no` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transfer_date` date NOT NULL,
  `from_account_id` int(11) NOT NULL,
  `to_account_id` int(11) NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_fin_transfer_no` (`transfer_no`),
  KEY `idx_fin_transfer_accounts` (`from_account_id`,`to_account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `invoice_items`;
CREATE TABLE `invoice_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `letter_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `letter_id` (`letter_id`),
  CONSTRAINT `invoice_items_ibfk_1` FOREIGN KEY (`letter_id`) REFERENCES `letters` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=latin1;

INSERT INTO `invoice_items` (`id`, `letter_id`, `item_name`, `amount`) VALUES (67, 2, 'Support Pengembangan & Pemeliharaan Aplikasi Dana Pensiun Telkom - Periode Juni 2026', '13583333.00');
INSERT INTO `invoice_items` (`id`, `letter_id`, `item_name`, `amount`) VALUES (71, 3, 'Support Pengembangan & Pemeliharaan Aplikasi Dana Pensiun Telkom - Periode Juli 2026', '13583333.00');
INSERT INTO `invoice_items` (`id`, `letter_id`, `item_name`, `amount`) VALUES (78, 4, 'Support Pengembangan & Pemeliharaan Aplikasi Dana Pensiun Telkom - Periode Agustus 2026', '13583333.00');
INSERT INTO `invoice_items` (`id`, `letter_id`, `item_name`, `amount`) VALUES (81, 5, 'Support Pengembangan & Pemeliharaan Aplikasi Dana Pensiun Telkom - Periode September 2026', '13583333.00');
INSERT INTO `invoice_items` (`id`, `letter_id`, `item_name`, `amount`) VALUES (88, 6, 'Support Pengembangan & Pemeliharaan Aplikasi Dana Pensiun Telkom - Periode Oktober 2026', '13583333.00');
INSERT INTO `invoice_items` (`id`, `letter_id`, `item_name`, `amount`) VALUES (114, 7, 'Paket Jasa Peningkatan Keamanan Siber Untuk Public Web Dana Pensiun Telkom', '69566523.00');
INSERT INTO `invoice_items` (`id`, `letter_id`, `item_name`, `amount`) VALUES (126, 8, ' Jasa Peningkatan Keamanan Siber untuk Public Web Dana Pensiun Telkom', '66891891.81');

DROP TABLE IF EXISTS `letters`;
CREATE TABLE `letters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `letter_number` varchar(100) NOT NULL,
  `letter_type` enum('GENERAL','INVOICE') DEFAULT 'GENERAL',
  `subject` varchar(255) NOT NULL,
  `letter_location` varchar(100) DEFAULT NULL,
  `letter_date` date NOT NULL,
  `recipient` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `signer_name` varchar(150) DEFAULT NULL,
  `signer_position` varchar(150) DEFAULT NULL,
  `attachment` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `description_closing` text,
  `signature_mode` varchar(20) DEFAULT 'MANUAL',
  `verify_token` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;

INSERT INTO `letters` (`id`, `client_id`, `letter_number`, `letter_type`, `subject`, `letter_location`, `letter_date`, `recipient`, `description`, `signer_name`, `signer_position`, `attachment`, `created_at`, `description_closing`, `signature_mode`, `verify_token`) VALUES (2, 1, '001/CROP-INV/VI/2026', 'INVOICE', 'PERMOHONAN PEMBAYARAN SUPPORT PENGEMBANGAN & PEMELIHARAAN APLIKASI DANA PENSIUN TELKOM', 'BANDUNG', '2026-06-25 00:00:00', 'DANA PENSIUN TELKOM', '<p style="text-align: justify;">Dengan&nbsp;hormat,&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p><p style="text-align: justify;">Sehubungan&nbsp;dengan&nbsp;<em>Support&nbsp;</em>Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom&nbsp;2026&nbsp;yang&nbsp;sesuai&nbsp;dengan&nbsp;Kontrak&nbsp;nomor:&nbsp;121/HK-71/Dapentel-020/2026&nbsp;yang&nbsp;telah&nbsp;dibuat,&nbsp;bersama&nbsp;ini&nbsp;kami&nbsp;mengajukan&nbsp;permohonan&nbsp;dengan&nbsp;penjelasan&nbsp;sebagai&nbsp;berikut:</p>', 'NAVA GIA GINASTA', 'Direktur Utama', '1', '2026-06-04 11:50:58', '<p style="text-align: justify;">Mohon&nbsp;kiranya&nbsp;pembayaran&nbsp;tersebut&nbsp;dapat&nbsp;dikirim/ditransfer&nbsp;melalui&nbsp;rekening&nbsp;:</p><p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nama&nbsp;Bank&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;Bank&nbsp;Mandiri</p><p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cabang&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;Gatot&nbsp;Subroto&nbsp;/&nbsp;Bandung</p><p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Rekening&nbsp;Nomor&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;131-00-1716997-2</p><p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Atas&nbsp;Nama&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;PT.&nbsp;Crop&nbsp;Inspirasi&nbsp;Digital</p><p style="text-align: justify;">Demikian&nbsp;permohonan&nbsp;ini&nbsp;dibuat,&nbsp;atas&nbsp;perhatian&nbsp;dan&nbsp;kerja&nbsp;samanya&nbsp;diucapkan&nbsp;terima&nbsp;kasih.</p>', 'MANUAL', '32b8d516270dbf4a241ddb6579ecec91');
INSERT INTO `letters` (`id`, `client_id`, `letter_number`, `letter_type`, `subject`, `letter_location`, `letter_date`, `recipient`, `description`, `signer_name`, `signer_position`, `attachment`, `created_at`, `description_closing`, `signature_mode`, `verify_token`) VALUES (3, 1, '002/CROP-INV/VII/2026', 'INVOICE', 'PERMOHONAN PEMBAYARAN SUPPORT PENGEMBANGAN & PEMELIHARAAN APLIKASI DANA PENSIUN TELKOM', 'BANDUNG', '2026-07-28 00:00:00', 'DANA PENSIUN TELKOM', '<p style="text-align: justify;">Dengan&nbsp;hormat,&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p><p style="text-align: justify;">Sehubungan&nbsp;dengan&nbsp;<em>Support&nbsp;</em>Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom&nbsp;2026&nbsp;yang&nbsp;sesuai&nbsp;dengan&nbsp;Kontrak&nbsp;nomor:&nbsp;121/HK-71/Dapentel-020/2026&nbsp;yang&nbsp;telah&nbsp;dibuat,&nbsp;bersama&nbsp;ini&nbsp;kami&nbsp;mengajukan&nbsp;permohonan&nbsp;dengan&nbsp;penjelasan&nbsp;sebagai&nbsp;berikut:</p>', 'NAVA GIA GINASTA', 'Direktur Utama', '1', '2026-07-22 12:17:00', '<p style="text-align: justify;">Mohon&nbsp;kiranya&nbsp;pembayaran&nbsp;tersebut&nbsp;dapat&nbsp;dikirim/ditransfer&nbsp;melalui&nbsp;rekening&nbsp;:</p><p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nama&nbsp;Bank&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;Bank&nbsp;Mandiri</p><p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cabang&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;Gatot&nbsp;Subroto&nbsp;/&nbsp;Bandung</p><p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Rekening&nbsp;Nomor&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;131-00-1716997-2</p><p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Atas&nbsp;Nama&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;PT.&nbsp;Crop&nbsp;Inspirasi&nbsp;Digital</p><p style="text-align: justify;">Demikian&nbsp;permohonan&nbsp;ini&nbsp;dibuat,&nbsp;atas&nbsp;perhatian&nbsp;dan&nbsp;kerja&nbsp;samanya&nbsp;diucapkan&nbsp;terima&nbsp;kasih.</p>', 'MANUAL', '13fb9cb04394d76c006fb8db414739a3');
INSERT INTO `letters` (`id`, `client_id`, `letter_number`, `letter_type`, `subject`, `letter_location`, `letter_date`, `recipient`, `description`, `signer_name`, `signer_position`, `attachment`, `created_at`, `description_closing`, `signature_mode`, `verify_token`) VALUES (4, 1, '003/CROP-INV/VIII/2026', 'INVOICE', 'PERMOHONAN PEMBAYARAN SUPPORT PENGEMBANGAN & PEMELIHARAAN APLIKASI DANA PENSIUN TELKOM', 'BANDUNG', '2026-08-27 00:00:00', 'DANA PENSIUN TELKOM', '<p style="text-align: justify;">Dengan&nbsp;hormat,&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p><p style="text-align: justify;">Sehubungan&nbsp;dengan&nbsp;<em>Support&nbsp;</em>Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom&nbsp;2026&nbsp;yang&nbsp;sesuai&nbsp;dengan&nbsp;Kontrak&nbsp;nomor:&nbsp;121/HK-71/Dapentel-020/2026&nbsp;yang&nbsp;telah&nbsp;dibuat,&nbsp;bersama&nbsp;ini&nbsp;kami&nbsp;mengajukan&nbsp;permohonan&nbsp;dengan&nbsp;penjelasan&nbsp;sebagai&nbsp;berikut:</p>', 'NAVA GIA GINASTA', 'Direktur Utama', '1', '2026-08-26 14:04:32', '<p style="text-align: justify;">Mohon&nbsp;kiranya&nbsp;pembayaran&nbsp;tersebut&nbsp;dapat&nbsp;dikirim/ditransfer&nbsp;melalui&nbsp;rekening&nbsp;:</p><p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nama&nbsp;Bank&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;Bank&nbsp;Mandiri</p><p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cabang&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;Gatot&nbsp;Subroto&nbsp;/&nbsp;Bandung</p><p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Rekening&nbsp;Nomor&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;131-00-1716997-2</p><p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Atas&nbsp;Nama&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;PT.&nbsp;Crop&nbsp;Inspirasi&nbsp;Digital</p><p style="text-align: justify;">Demikian&nbsp;permohonan&nbsp;ini&nbsp;dibuat,&nbsp;atas&nbsp;perhatian&nbsp;dan&nbsp;kerja&nbsp;samanya&nbsp;diucapkan&nbsp;terima&nbsp;kasih.</p>', 'MANUAL', '34d527c19a442fc6fbce00ed5b602061');
INSERT INTO `letters` (`id`, `client_id`, `letter_number`, `letter_type`, `subject`, `letter_location`, `letter_date`, `recipient`, `description`, `signer_name`, `signer_position`, `attachment`, `created_at`, `description_closing`, `signature_mode`, `verify_token`) VALUES (5, 1, '004/CROP-INV/IX/2026', 'INVOICE', 'PERMOHONAN PEMBAYARAN SUPPORT PENGEMBANGAN & PEMELIHARAAN APLIKASI DANA PENSIUN TELKOM', 'BANDUNG', '2026-09-25 00:00:00', 'DANA PENSIUN TELKOM', '<p style="text-align: justify;">Dengan&nbsp;hormat,&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p><p style="text-align: justify;">Sehubungan&nbsp;dengan&nbsp;<em>Support&nbsp;</em>Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom&nbsp;2026&nbsp;yang&nbsp;sesuai&nbsp;dengan&nbsp;Kontrak&nbsp;nomor:&nbsp;121/HK-71/Dapentel-020/2026&nbsp;yang&nbsp;telah&nbsp;dibuat,&nbsp;bersama&nbsp;ini&nbsp;kami&nbsp;mengajukan&nbsp;permohonan&nbsp;dengan&nbsp;penjelasan&nbsp;sebagai&nbsp;berikut:</p>', 'NAVA GIA GINASTA', 'Direktur Utama', '1', '2026-09-08 10:50:34', '<p style="text-align: justify;">Mohon&nbsp;kiranya&nbsp;pembayaran&nbsp;tersebut&nbsp;dapat&nbsp;dikirim/ditransfer&nbsp;melalui&nbsp;rekening&nbsp;:</p><p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nama&nbsp;Bank&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;Bank&nbsp;Mandiri</p><p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cabang&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;Gatot&nbsp;Subroto&nbsp;/&nbsp;Bandung</p><p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Rekening&nbsp;Nomor&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;131-00-1716997-2</p><p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Atas&nbsp;Nama&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;PT.&nbsp;Crop&nbsp;Inspirasi&nbsp;Digital</p><p style="text-align: justify;">Demikian&nbsp;permohonan&nbsp;ini&nbsp;dibuat,&nbsp;atas&nbsp;perhatian&nbsp;dan&nbsp;kerja&nbsp;samanya&nbsp;diucapkan&nbsp;terima&nbsp;kasih.</p>', 'MANUAL', '5c9627cded7533bca257f8b7ddf48e02');
INSERT INTO `letters` (`id`, `client_id`, `letter_number`, `letter_type`, `subject`, `letter_location`, `letter_date`, `recipient`, `description`, `signer_name`, `signer_position`, `attachment`, `created_at`, `description_closing`, `signature_mode`, `verify_token`) VALUES (6, 1, '005/CROP-INV/X/2026', 'INVOICE', 'PERMOHONAN PEMBAYARAN SUPPORT PENGEMBANGAN & PEMELIHARAAN APLIKASI DANA PENSIUN TELKOM', 'BANDUNG', '2026-10-31 00:00:00', 'DANA PENSIUN TELKOM', '<p style="text-align: justify;">Dengan&nbsp;hormat,&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p><p style="text-align: justify;">Sehubungan&nbsp;dengan&nbsp;<em>Support&nbsp;</em>Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom&nbsp;2026&nbsp;yang&nbsp;sesuai&nbsp;dengan&nbsp;Kontrak&nbsp;nomor:&nbsp;121/HK-71/Dapentel-020/2026&nbsp;yang&nbsp;telah&nbsp;dibuat,&nbsp;bersama&nbsp;ini&nbsp;kami&nbsp;mengajukan&nbsp;permohonan&nbsp;dengan&nbsp;penjelasan&nbsp;sebagai&nbsp;berikut:</p>', 'NAVA GIA GINASTA', 'Direktur Utama', '1', '2026-10-12 10:57:30', '<p style="text-align: justify;">Mohon&nbsp;kiranya&nbsp;pembayaran&nbsp;tersebut&nbsp;dapat&nbsp;dikirim/ditransfer&nbsp;melalui&nbsp;rekening&nbsp;:</p><p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nama&nbsp;Bank&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;Bank&nbsp;Mandiri</p><p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cabang&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;Gatot&nbsp;Subroto&nbsp;/&nbsp;Bandung</p><p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Rekening&nbsp;Nomor&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;131-00-1716997-2</p><p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Atas&nbsp;Nama&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;PT.&nbsp;Crop&nbsp;Inspirasi&nbsp;Digital</p><p style="text-align: justify;">Demikian&nbsp;permohonan&nbsp;ini&nbsp;dibuat,&nbsp;atas&nbsp;perhatian&nbsp;dan&nbsp;kerja&nbsp;samanya&nbsp;diucapkan&nbsp;terima&nbsp;kasih.</p>', 'MANUAL', '3adb571bffacaabff2cb13256e03aabc');
INSERT INTO `letters` (`id`, `client_id`, `letter_number`, `letter_type`, `subject`, `letter_location`, `letter_date`, `recipient`, `description`, `signer_name`, `signer_position`, `attachment`, `created_at`, `description_closing`, `signature_mode`, `verify_token`) VALUES (7, 1, '006/CROP-INV/X/2026', 'INVOICE', 'SURAT PENAWARAN HARGA ', 'Bandung', '2026-10-29 00:00:00', 'DANA PENSIUN TELKOM', '<p>Dengan&nbsp;hormat,</p><p>Kami&nbsp;dari&nbsp;PT&nbsp;Crop&nbsp;Inspirasi&nbsp;Digital&nbsp;bermaksud&nbsp;menyampaikan&nbsp;penawaran&nbsp;harga&nbsp;berdasarkan&nbsp;Surat&nbsp;Permintaan&nbsp;Penawaran&nbsp;Harga&nbsp;(SPPH)&nbsp;nomor&nbsp;1389/LG-29/Dapentel-012/2026&nbsp;terkait&nbsp;Pengadaan&nbsp;Jasa&nbsp;Peningkatan&nbsp;Keamanan&nbsp;Siber&nbsp;Untuk&nbsp;Public&nbsp;Web&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom,&nbsp;sesuai&nbsp;dengan&nbsp;spesifikasi&nbsp;TOR&nbsp;(Term&nbsp;of&nbsp;Reference)&nbsp;yang&nbsp;telah&nbsp;kami&nbsp;terima.&nbsp;Bersama&nbsp;surat&nbsp;ini,&nbsp;kami&nbsp;sampaikan&nbsp;rincian&nbsp;harga&nbsp;penawaran&nbsp;yang&nbsp;kami&nbsp;tawarkan&nbsp;sebagai&nbsp;berikut:</p>', 'Nava Gia Ginasta, M.Kom.', 'Direktur Utama', '-', '2026-10-30 22:04:06', '<p>Demikian&nbsp;surat&nbsp;penawaran&nbsp;harga&nbsp;ini&nbsp;kami&nbsp;sampaikan&nbsp;besar&nbsp;harapan&nbsp;kami&nbsp;bapak&nbsp;berminat&nbsp;dengan&nbsp;harga&nbsp;yang&nbsp;kami&nbsp;tawarkan.&nbsp;Atas&nbsp;perhatiannya&nbsp;kami&nbsp;ucapkan&nbsp;terima&nbsp;kasih.</p>', 'MANUAL', '7f39567e48140a0f397cb43b5ef576c0');
INSERT INTO `letters` (`id`, `client_id`, `letter_number`, `letter_type`, `subject`, `letter_location`, `letter_date`, `recipient`, `description`, `signer_name`, `signer_position`, `attachment`, `created_at`, `description_closing`, `signature_mode`, `verify_token`) VALUES (8, 1, '007/CROP-INV/XI/2026', 'INVOICE', 'PERMOHONAN PEMBAYARAN JASA PENINGKATAN KEAMANAN SIBER UNTUK PUBLIC WEB DANA PENSIUN TELKOM', 'BANDUNG', '2026-11-20 00:00:00', 'DANA PENSIUN TELKOM', '<p style="text-align: justify;">Dengan&nbsp;hormat,&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p><p style="text-align: justify;">Sehubungan&nbsp;dengan&nbsp;Jasa&nbsp;Peningkatan&nbsp;Keamanan&nbsp;Siber&nbsp;untuk&nbsp;Public&nbsp;Web&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom&nbsp;2026&nbsp;yang&nbsp;sesuai&nbsp;dengan&nbsp;Nota&nbsp;Pesanan&nbsp;nomor:&nbsp;1424/LG-29/Dapentel-012/2026,&nbsp;&nbsp;bersama&nbsp;ini&nbsp;kami&nbsp;mengajukan&nbsp;permohonan&nbsp;dengan&nbsp;penjelasan&nbsp;sebagai&nbsp;berikut:</p>', 'NAVA GIA GINASTA', 'Direktur Utama', '1', '2026-11-05 11:57:29', '<p style="text-align: justify;">Mohon&nbsp;kiranya&nbsp;pembayaran&nbsp;tersebut&nbsp;dapat&nbsp;dikirim/ditransfer&nbsp;melalui&nbsp;rekening&nbsp;:</p><p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nama&nbsp;Bank&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;Bank&nbsp;Mandiri</p><p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cabang&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;Gatot&nbsp;Subroto&nbsp;/&nbsp;Bandung</p><p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Rekening&nbsp;Nomor&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;131-00-1716997-2</p><p style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Atas&nbsp;Nama&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;PT.&nbsp;Crop&nbsp;Inspirasi&nbsp;Digital</p><p style="text-align: justify;">Demikian&nbsp;permohonan&nbsp;ini&nbsp;dibuat,&nbsp;atas&nbsp;perhatian&nbsp;dan&nbsp;kerja&nbsp;samanya&nbsp;diucapkan&nbsp;terima&nbsp;kasih.</p>', 'MANUAL', '7533149ce906151117c1332089294466');

DROP TABLE IF EXISTS `marketing_activity_logs`;
CREATE TABLE `marketing_activity_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Unknown',
  `role_id` int(11) DEFAULT NULL,
  `action` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_marketing_activity_logs_user` (`user_id`),
  KEY `idx_marketing_activity_logs_module` (`module`),
  KEY `idx_marketing_activity_logs_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=158 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (1, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 04:44:57');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (2, 2, 'Nava Gia Ginasta', 1, 'create', 'Kampanye', 'Menambah kampanye n', '2026-11-22 04:45:26');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (3, 2, 'Nava Gia Ginasta', 1, 'start', 'Kampanye', 'Memulai kampanye n', '2026-11-22 04:45:29');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (4, 2, 'Nava Gia Ginasta', 1, 'duplicate', 'Kampanye', 'Menduplikat kampanye #1', '2026-11-22 04:46:00');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (5, 2, 'Nava Gia Ginasta', 1, 'delete', 'Kampanye', 'Menghapus kampanye #2', '2026-11-22 04:46:03');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (6, 2, 'Nava Gia Ginasta', 1, 'create', 'Kontak Marketing', 'Menambah kontak Nava Gia Ginasta', '2026-11-22 04:46:25');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (7, 2, 'Nava Gia Ginasta', 1, 'update', 'Kampanye', 'Memperbarui kampanye #1', '2026-11-22 04:47:15');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (8, 2, 'Nava Gia Ginasta', 1, 'start', 'Kampanye', 'Memulai kampanye n', '2026-11-22 04:47:15');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (9, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 04:48:25');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (10, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 04:50:23');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (11, 2, 'Nava Gia Ginasta', 1, 'update', 'Kampanye', 'Memperbarui kampanye #1', '2026-11-22 04:50:56');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (12, 2, 'Nava Gia Ginasta', 1, 'update', 'Kampanye', 'Memperbarui kampanye #1', '2026-11-22 04:51:14');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (13, 2, 'Nava Gia Ginasta', 1, 'start', 'Kampanye', 'Memulai kampanye n', '2026-11-22 04:51:14');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (14, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 04:57:17');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (15, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 04:57:18');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (16, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 05:05:18');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (17, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 05:05:21');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (18, 2, 'Nava Gia Ginasta', 1, 'pause', 'Kampanye', 'Menjeda kampanye n', '2026-11-22 05:05:28');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (19, 2, 'Nava Gia Ginasta', 1, 'update', 'Kampanye', 'Memperbarui kampanye #1', '2026-11-22 05:05:35');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (20, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:06:07');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (21, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 05:06:24');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (22, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:06:26');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (23, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 05:06:33');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (24, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:06:35');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (25, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:06:41');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (26, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:07:00');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (27, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:07:11');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (28, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:07:15');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (29, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:07:22');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (30, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:07:29');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (31, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 05:23:17');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (32, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:23:20');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (33, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:27:14');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (34, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:27:15');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (35, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:27:22');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (36, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:27:24');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (37, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:27:46');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (38, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:29:43');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (39, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:29:43');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (40, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:29:44');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (41, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:29:44');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (42, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:29:45');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (43, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:32:57');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (44, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:32:59');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (45, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:33:01');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (46, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:33:02');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (47, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 05:33:14');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (48, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:33:18');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (49, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 05:33:44');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (50, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:36:27');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (51, 2, 'Nava Gia Ginasta', 1, 'delete', 'Kontak Marketing', 'Menghapus 1 kontak', '2026-11-22 05:37:26');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (52, 2, 'Nava Gia Ginasta', 1, 'delete', 'Kampanye', 'Menghapus kampanye #1', '2026-11-22 05:39:22');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (53, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi SMTP', '2026-11-22 05:39:47');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (54, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 05:40:04');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (55, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 05:40:32');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (56, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 05:40:50');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (57, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 05:40:50');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (58, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 05:40:59');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (59, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 05:41:07');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (60, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 05:41:15');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (61, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 05:41:23');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (62, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 05:41:25');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (63, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 05:41:28');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (64, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 05:42:50');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (65, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 05:46:34');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (66, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 05:46:36');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (67, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 05:46:38');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (68, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 05:51:18');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (69, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 05:51:21');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (70, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 05:51:27');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (71, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 05:52:25');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (72, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 05:56:38');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (73, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 05:56:40');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (74, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 05:56:45');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (75, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 05:56:53');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (76, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 05:56:57');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (77, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 05:57:02');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (78, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 05:57:35');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (79, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 05:57:44');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (80, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 05:58:11');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (81, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 05:58:17');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (82, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:06:34');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (83, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 06:06:39');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (84, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:06:41');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (85, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:06:42');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (86, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:06:43');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (87, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:06:44');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (88, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:09:11');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (89, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 06:09:17');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (90, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:09:19');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (91, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 06:12:56');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (92, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 06:18:08');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (93, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:18:10');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (94, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:18:18');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (95, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:18:22');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (96, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 06:20:08');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (97, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:20:10');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (98, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:20:13');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (99, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:20:14');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (100, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:20:20');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (101, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 06:21:13');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (102, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:21:14');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (103, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:22:20');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (104, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:22:21');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (105, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:22:21');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (106, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:22:45');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (107, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:22:46');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (108, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:24:18');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (109, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 06:30:25');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (110, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 06:30:33');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (111, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:37:42');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (112, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:37:48');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (113, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 06:37:55');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (114, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:37:56');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (115, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:37:58');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (116, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:37:58');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (117, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 06:47:32');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (118, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:47:34');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (119, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:48:34');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (120, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 06:48:36');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (121, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:48:38');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (122, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:48:40');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (123, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:48:40');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (124, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 06:49:22');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (125, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:49:23');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (126, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 06:49:40');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (127, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 06:49:55');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (128, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 06:50:21');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (129, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:50:23');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (130, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:50:25');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (131, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:50:25');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (132, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:50:26');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (133, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 06:52:58');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (134, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:53:00');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (135, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:55:45');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (136, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 06:56:59');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (137, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:57:01');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (138, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 06:57:45');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (139, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:57:47');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (140, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:57:50');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (141, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:57:52');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (142, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:57:54');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (143, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 06:58:22');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (144, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 06:58:25');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (145, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 07:04:46');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (146, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 07:04:49');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (147, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 07:04:50');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (148, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 07:04:58');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (149, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 07:05:00');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (150, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 07:05:02');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (151, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 07:14:12');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (152, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 07:14:14');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (153, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 07:14:19');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (154, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 07:14:23');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (155, 2, 'Nava Gia Ginasta', 1, 'error', 'Pengaturan Marketing', 'Gagal menguji koneksi email', '2026-11-22 07:14:24');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (156, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 07:32:11');
INSERT INTO `marketing_activity_logs` (`id`, `user_id`, `user_name`, `role_id`, `action`, `module`, `description`, `created_at`) VALUES (157, 2, 'Nava Gia Ginasta', 1, 'update', 'Pengaturan Marketing', 'Memperbarui pengaturan integrasi marketing', '2026-11-22 08:16:50');

DROP TABLE IF EXISTS `marketing_campaign_recipients`;
CREATE TABLE `marketing_campaign_recipients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_id` int(10) unsigned NOT NULL,
  `contact_id` int(10) unsigned NOT NULL,
  `channel` enum('email','whatsapp') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','queued','sent','delivered','opened','clicked','bounced','failed','read','invalid','skipped') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `attempts` int(11) NOT NULL DEFAULT '0',
  `last_error` text COLLATE utf8mb4_unicode_ci,
  `external_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `delivered_at` datetime DEFAULT NULL,
  `opened_at` datetime DEFAULT NULL,
  `clicked_at` datetime DEFAULT NULL,
  `read_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_marketing_campaign_recipients_target` (`campaign_id`,`contact_id`,`channel`),
  KEY `idx_marketing_campaign_recipients_status` (`campaign_id`,`status`),
  KEY `idx_marketing_campaign_recipients_contact` (`contact_id`),
  KEY `idx_marketing_campaign_recipients_external` (`external_id`),
  CONSTRAINT `fk_marketing_campaign_recipients_campaign` FOREIGN KEY (`campaign_id`) REFERENCES `marketing_campaigns` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_marketing_campaign_recipients_contact` FOREIGN KEY (`contact_id`) REFERENCES `marketing_contacts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `marketing_campaigns`;
CREATE TABLE `marketing_campaigns` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('email','whatsapp','both') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'email',
  `status` enum('draft','scheduled','queued','running','completed','cancelled','paused') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `recipients_config` longtext COLLATE utf8mb4_unicode_ci,
  `email_subject` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_from_name` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_from_email` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_template_id` int(10) unsigned DEFAULT NULL,
  `email_content` longtext COLLATE utf8mb4_unicode_ci,
  `email_schedule_at` datetime DEFAULT NULL,
  `whatsapp_template_id` int(10) unsigned DEFAULT NULL,
  `whatsapp_content` text COLLATE utf8mb4_unicode_ci,
  `whatsapp_schedule_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_marketing_campaigns_status` (`status`),
  KEY `idx_marketing_campaigns_type` (`type`),
  KEY `idx_marketing_campaigns_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `marketing_consent_logs`;
CREATE TABLE `marketing_consent_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `contact_id` int(10) unsigned NOT NULL,
  `action` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `note` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_marketing_consent_logs_contact` (`contact_id`),
  KEY `idx_marketing_consent_logs_created_at` (`created_at`),
  CONSTRAINT `fk_marketing_consent_logs_contact` FOREIGN KEY (`contact_id`) REFERENCES `marketing_contacts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `marketing_contact_group_members`;
CREATE TABLE `marketing_contact_group_members` (
  `group_id` int(10) unsigned NOT NULL,
  `contact_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`group_id`,`contact_id`),
  KEY `idx_marketing_group_members_contact` (`contact_id`),
  CONSTRAINT `fk_marketing_group_members_contact` FOREIGN KEY (`contact_id`) REFERENCES `marketing_contacts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_marketing_group_members_group` FOREIGN KEY (`group_id`) REFERENCES `marketing_contact_groups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `marketing_contact_groups`;
CREATE TABLE `marketing_contact_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'custom',
  `filter_rules` longtext COLLATE utf8mb4_unicode_ci,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_marketing_contact_groups_name` (`name`),
  KEY `idx_marketing_contact_groups_type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `marketing_contacts`;
CREATE TABLE `marketing_contacts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `segment` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Prospek',
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opt_in` tinyint(1) NOT NULL DEFAULT '0',
  `consent_at` datetime DEFAULT NULL,
  `unsubscribed` tinyint(1) NOT NULL DEFAULT '0',
  `unsubscribed_at` datetime DEFAULT NULL,
  `unsubscribe_token` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `extra` longtext COLLATE utf8mb4_unicode_ci,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_marketing_contacts_email` (`email`),
  UNIQUE KEY `uq_marketing_contacts_whatsapp` (`whatsapp`),
  UNIQUE KEY `uq_marketing_contacts_unsubscribe_token` (`unsubscribe_token`),
  KEY `idx_marketing_contacts_segment` (`segment`),
  KEY `idx_marketing_contacts_category` (`category`),
  KEY `idx_marketing_contacts_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `marketing_email_logs`;
CREATE TABLE `marketing_email_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_id` int(10) unsigned DEFAULT NULL,
  `recipient_id` bigint(20) unsigned DEFAULT NULL,
  `contact_id` int(10) unsigned DEFAULT NULL,
  `event` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `detail` longtext COLLATE utf8mb4_unicode_ci,
  `occurred_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_marketing_email_logs_campaign` (`campaign_id`),
  KEY `idx_marketing_email_logs_recipient` (`recipient_id`),
  KEY `idx_marketing_email_logs_contact` (`contact_id`),
  KEY `idx_marketing_email_logs_event` (`event`),
  KEY `idx_marketing_email_logs_occurred_at` (`occurred_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `marketing_email_logs` (`id`, `campaign_id`, `recipient_id`, `contact_id`, `event`, `message_id`, `detail`, `occurred_at`) VALUES (1, 1, 1, 1, 'failed', NULL, '{"queue_id":1,"attempts":1,"max_attempts":3,"error":"SMTP Error: Could not connect to SMTP host. Failed to connect to server","recipient_status":"failed"}', '2026-11-22 04:49:49');
INSERT INTO `marketing_email_logs` (`id`, `campaign_id`, `recipient_id`, `contact_id`, `event`, `message_id`, `detail`, `occurred_at`) VALUES (2, 1, 1, 1, 'failed', NULL, '{"queue_id":1,"attempts":2,"max_attempts":3,"error":"SMTP Error: Could not connect to SMTP host. Failed to connect to server","recipient_status":"failed"}', '2026-11-22 04:50:32');
INSERT INTO `marketing_email_logs` (`id`, `campaign_id`, `recipient_id`, `contact_id`, `event`, `message_id`, `detail`, `occurred_at`) VALUES (3, 1, 1, 1, 'failed', NULL, '{"queue_id":1,"attempts":3,"max_attempts":3,"error":"SMTP Error: Could not connect to SMTP host. Failed to connect to server","recipient_status":"failed"}', '2026-11-22 04:51:02');

DROP TABLE IF EXISTS `marketing_email_templates`;
CREATE TABLE `marketing_email_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `html` longtext COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_marketing_email_templates_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `marketing_queue`;
CREATE TABLE `marketing_queue` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `channel` enum('email','whatsapp') COLLATE utf8mb4_unicode_ci NOT NULL,
  `campaign_id` int(10) unsigned DEFAULT NULL,
  `recipient_id` bigint(20) unsigned DEFAULT NULL,
  `contact_id` int(10) unsigned DEFAULT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci,
  `status` enum('pending','processing','done','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `attempts` int(11) NOT NULL DEFAULT '0',
  `max_attempts` int(11) NOT NULL DEFAULT '3',
  `available_at` datetime NOT NULL,
  `locked_at` datetime DEFAULT NULL,
  `locked_by` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_error` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `processed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_marketing_queue_channel_status` (`channel`,`status`),
  KEY `idx_marketing_queue_available` (`status`,`available_at`),
  KEY `idx_marketing_queue_campaign` (`campaign_id`),
  KEY `idx_marketing_queue_recipient` (`recipient_id`),
  KEY `idx_marketing_queue_lock` (`status`,`locked_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `marketing_queue` (`id`, `channel`, `campaign_id`, `recipient_id`, `contact_id`, `payload`, `status`, `attempts`, `max_attempts`, `available_at`, `locked_at`, `locked_by`, `last_error`, `created_at`, `processed_at`) VALUES (1, 'email', 1, 1, 1, '{"campaign_id":1,"campaign_name":"n","recipient_id":1,"contact_id":1,"channel":"email","email_subject":"navagiaginasta@gmail.com","email_content":"<p>test</p>","email_from_name":"marketing@crop.co.id","email_from_email":"navagiaginasta@gmail.com","email_template_id":0,"whatsapp_template_id":0,"whatsapp_template_name":"","whatsapp_language":"id","whatsapp_components":null,"whatsapp_content":"","contact":{"id":1,"name":"Nava Gia Ginasta","email":"navagiaginasta@gmail.com","whatsapp":"6268782033395","company":"PT Crop Inspirasi Digital","category":"","segment":"Prospek","unsubscribe_token":"64437368-c494-4561-a79d-74830c0009c9"}}', 'failed', 3, 3, '2026-11-22 11:50:36', NULL, NULL, 'SMTP Error: Could not connect to SMTP host. Failed to connect to server', '2026-11-22 04:47:15', '2026-11-22 04:51:02');
INSERT INTO `marketing_queue` (`id`, `channel`, `campaign_id`, `recipient_id`, `contact_id`, `payload`, `status`, `attempts`, `max_attempts`, `available_at`, `locked_at`, `locked_by`, `last_error`, `created_at`, `processed_at`) VALUES (2, 'email', 1, 1, 1, '{"campaign_id":1,"campaign_name":"n","recipient_id":1,"contact_id":1,"channel":"email","email_subject":"navagiaginasta@gmail.com","email_content":"<p>test</p>","email_from_name":"marketing@crop.co.id","email_from_email":"navagiaginasta@gmail.com","email_template_id":0,"whatsapp_template_id":0,"whatsapp_template_name":"","whatsapp_language":"id","whatsapp_components":null,"whatsapp_content":"","contact":{"id":1,"name":"Nava Gia Ginasta","email":"navagiaginasta@gmail.com","whatsapp":"6268782033395","company":"PT Crop Inspirasi Digital","category":"","segment":"Prospek","unsubscribe_token":"64437368-c494-4561-a79d-74830c0009c9"}}', 'pending', 0, 3, '2026-11-22 04:51:14', NULL, NULL, NULL, '2026-11-22 04:51:14', NULL);

DROP TABLE IF EXISTS `marketing_rate_limits`;
CREATE TABLE `marketing_rate_limits` (
  `rate_key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hits` int(11) NOT NULL DEFAULT '0',
  `window_start` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`rate_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `marketing_rate_limits` (`rate_key`, `hits`, `window_start`, `created_at`) VALUES ('mkt_api_test_email:1', 1, '2026-11-22 06:56:15', '2026-11-22 06:56:15');
INSERT INTO `marketing_rate_limits` (`rate_key`, `hits`, `window_start`, `created_at`) VALUES ('mkt_api_test_email:2', 2, '2026-11-22 05:06:00', '2026-11-22 05:06:00');
INSERT INTO `marketing_rate_limits` (`rate_key`, `hits`, `window_start`, `created_at`) VALUES ('mkt_api_test_smtp:1', 1, '2026-11-22 06:55:45', '2026-11-22 04:48:23');
INSERT INTO `marketing_rate_limits` (`rate_key`, `hits`, `window_start`, `created_at`) VALUES ('mkt_api_test_smtp:2', 7, '2026-11-22 07:14:12', '2026-11-22 04:57:16');
INSERT INTO `marketing_rate_limits` (`rate_key`, `hits`, `window_start`, `created_at`) VALUES ('mkt_api_test_whatsapp:2', 1, '2026-11-22 07:14:28', '2026-11-22 04:44:31');

DROP TABLE IF EXISTS `marketing_settings`;
CREATE TABLE `marketing_settings` (
  `setting_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `setting_value` longtext COLLATE utf8mb4_unicode_ci,
  `is_encrypted` tinyint(1) NOT NULL DEFAULT '0',
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `marketing_settings` (`setting_key`, `setting_value`, `is_encrypted`, `updated_by`, `updated_at`) VALUES ('email_provider', 'gmail', 0, 2, '2026-11-22 08:16:50');
INSERT INTO `marketing_settings` (`setting_key`, `setting_value`, `is_encrypted`, `updated_by`, `updated_at`) VALUES ('gmail_client_id', '403881763574-3tipgoakju3nsmu2qj5jtl54e994n9a8.apps.googleusercontent.com', 0, 2, '2026-11-22 08:16:50');
INSERT INTO `marketing_settings` (`setting_key`, `setting_value`, `is_encrypted`, `updated_by`, `updated_at`) VALUES ('gmail_client_secret', 'v1:qRi+tGzL1nFQlB4i:00mYcBiqzcRVaD0MYx+CRQ==:ZGuREOjBRUWzvo6aXUgg9hkPOfJ3xxOsdmpCmfxgGvGQUtU=', 1, 2, '2026-11-22 07:32:11');
INSERT INTO `marketing_settings` (`setting_key`, `setting_value`, `is_encrypted`, `updated_by`, `updated_at`) VALUES ('gmail_refresh_token', '', 1, 2, '2026-11-22 06:52:58');
INSERT INTO `marketing_settings` (`setting_key`, `setting_value`, `is_encrypted`, `updated_by`, `updated_at`) VALUES ('gmail_user', 'crop.indonesia@gmail.com', 0, 2, '2026-11-22 08:16:50');
INSERT INTO `marketing_settings` (`setting_key`, `setting_value`, `is_encrypted`, `updated_by`, `updated_at`) VALUES ('smtp_auth', '1', 0, 2, '2026-11-22 08:16:50');
INSERT INTO `marketing_settings` (`setting_key`, `setting_value`, `is_encrypted`, `updated_by`, `updated_at`) VALUES ('smtp_encryption', 'ssl', 0, 2, '2026-11-22 08:16:50');
INSERT INTO `marketing_settings` (`setting_key`, `setting_value`, `is_encrypted`, `updated_by`, `updated_at`) VALUES ('smtp_from_email', 'crop.indonesia@gmail.com', 0, 2, '2026-11-22 08:16:50');
INSERT INTO `marketing_settings` (`setting_key`, `setting_value`, `is_encrypted`, `updated_by`, `updated_at`) VALUES ('smtp_from_name', 'CROP Marketing', 0, 2, '2026-11-22 08:16:50');
INSERT INTO `marketing_settings` (`setting_key`, `setting_value`, `is_encrypted`, `updated_by`, `updated_at`) VALUES ('smtp_host', 'loyal.jagoanhosting.id', 0, 2, '2026-11-22 08:16:50');
INSERT INTO `marketing_settings` (`setting_key`, `setting_value`, `is_encrypted`, `updated_by`, `updated_at`) VALUES ('smtp_pass', '', 0, 2, '2026-11-22 06:49:40');
INSERT INTO `marketing_settings` (`setting_key`, `setting_value`, `is_encrypted`, `updated_by`, `updated_at`) VALUES ('smtp_port', '465', 0, 2, '2026-11-22 08:16:50');
INSERT INTO `marketing_settings` (`setting_key`, `setting_value`, `is_encrypted`, `updated_by`, `updated_at`) VALUES ('smtp_status_at', '', 0, NULL, '2026-11-22 08:16:50');
INSERT INTO `marketing_settings` (`setting_key`, `setting_value`, `is_encrypted`, `updated_by`, `updated_at`) VALUES ('smtp_status_message', 'Konfigurasi berubah. Uji ulang koneksi email.', 0, NULL, '2026-11-22 08:16:50');
INSERT INTO `marketing_settings` (`setting_key`, `setting_value`, `is_encrypted`, `updated_by`, `updated_at`) VALUES ('smtp_status_ok', '', 0, NULL, '2026-11-22 08:16:50');
INSERT INTO `marketing_settings` (`setting_key`, `setting_value`, `is_encrypted`, `updated_by`, `updated_at`) VALUES ('smtp_user', 'marketing@crop.co.id', 0, 2, '2026-11-22 08:16:50');
INSERT INTO `marketing_settings` (`setting_key`, `setting_value`, `is_encrypted`, `updated_by`, `updated_at`) VALUES ('whatsapp_api_version', 'v21.0', 0, 2, '2026-11-22 08:16:50');

DROP TABLE IF EXISTS `marketing_unsubscribes`;
CREATE TABLE `marketing_unsubscribes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `contact_id` int(10) unsigned DEFAULT NULL,
  `email` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `channel` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'all',
  `source` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_marketing_unsubscribes_email_channel` (`email`,`channel`),
  KEY `idx_marketing_unsubscribes_contact` (`contact_id`),
  CONSTRAINT `fk_marketing_unsubscribes_contact` FOREIGN KEY (`contact_id`) REFERENCES `marketing_contacts` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `marketing_whatsapp_logs`;
CREATE TABLE `marketing_whatsapp_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `campaign_id` int(10) unsigned DEFAULT NULL,
  `recipient_id` bigint(20) unsigned DEFAULT NULL,
  `contact_id` int(10) unsigned DEFAULT NULL,
  `event` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `detail` longtext COLLATE utf8mb4_unicode_ci,
  `occurred_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_marketing_whatsapp_logs_campaign` (`campaign_id`),
  KEY `idx_marketing_whatsapp_logs_recipient` (`recipient_id`),
  KEY `idx_marketing_whatsapp_logs_contact` (`contact_id`),
  KEY `idx_marketing_whatsapp_logs_event` (`event`),
  KEY `idx_marketing_whatsapp_logs_occurred_at` (`occurred_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `marketing_whatsapp_templates`;
CREATE TABLE `marketing_whatsapp_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `template_name` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'id',
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `components` longtext COLLATE utf8mb4_unicode_ci,
  `content` text COLLATE utf8mb4_unicode_ci,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_marketing_whatsapp_templates_name` (`template_name`),
  KEY `idx_marketing_whatsapp_templates_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `title` varchar(150) NOT NULL,
  `url` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `menu_order` int(11) NOT NULL,
  `type` varchar(100) DEFAULT NULL,
  `is_view` int(11) DEFAULT '0',
  `is_create` int(11) DEFAULT NULL,
  `is_edit` int(11) DEFAULT NULL,
  `is_delete` int(11) DEFAULT NULL,
  `is_export` int(11) DEFAULT NULL,
  `is_duplicate` int(11) DEFAULT NULL,
  `is_unlock` int(11) DEFAULT NULL,
  `is_active` int(11) DEFAULT NULL,
  `class_active` varchar(255) DEFAULT NULL,
  `icon` text,
  PRIMARY KEY (`menu_id`) USING BTREE,
  UNIQUE KEY `NewIndex1` (`menu_id`,`parent_id`) USING BTREE,
  KEY `parent_id` (`parent_id`) USING BTREE,
  CONSTRAINT `bd_m_menu_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `menu` (`menu_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=323 DEFAULT CHARSET=utf8;

INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (1, 1, 'Dashboard', 'dashboard', 'Home', 1, '2', 1, 1, 1, 1, 1, 0, 0, 1, '1', 'LayoutDashboard');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (9, 1, 'Access Management', 'hak_akses', 'Access Management', 20, '2', 1, 1, 1, 1, 1, 1, 1, 1, '9', 'Users');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (10, 1, 'Backup and Log', 'backup', 'Backup and Log', 121, '2', 1, 1, 1, 1, 1, 1, 1, 1, '10', 'LayoutDashboard');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (11, 1, 'App Configuration', 'setting', 'App Configuration', 22, '2', 1, 1, 1, 1, 1, 1, 1, 1, '11', 'LayoutDashboard');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (12, 9, 'Module Admin', 'hak-akses/menu', 'Access Management - Module Admin', 2, '2', 1, 1, 1, 1, 1, 1, 1, 1, '9,12', 'Menu');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (14, 9, 'Module Authority', 'hak-akses/module-authority', 'Access Management - Module Authority', 3, '2', 1, 1, 1, 1, 1, 1, 1, 1, '9,14', 'Layers');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (15, 9, 'User Management', 'hak-akses/user', 'Access Management - User Management', 4, '2', 1, 1, 1, 1, 1, 1, 1, 1, '9,15', 'User');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (16, 9, 'Role Management', 'hak-akses/role', 'Access Management - Role Management', 5, '2', 1, 1, 1, 1, 1, 1, 1, 1, '9,16', 'UserCheck');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (122, 10, 'Log Activity Admin', 'backup/log', 'Backup and Log - Log Activity Admin', 2, '2', 1, 1, 1, 1, 1, 1, 1, 1, '10,122', 'LayoutDashboard');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (123, 10, 'Backup & Restore', 'backup/housekeeping', 'Backup and Log - Backup & Restore', 3, '2', 1, 1, 1, 1, 1, 1, 1, 1, '10,123', 'LayoutDashboard');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (131, 1, 'Data Administration', 'administrasi', 'Data Administration', 18, '2', 1, 1, 1, 1, 1, 1, 1, 0, '131', 'LayoutDashboard');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (142, 1, 'Internal', NULL, NULL, 7, '2', 1, 1, 1, 1, 1, 1, 1, 1, '142', 'FileText');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (147, 142, 'Klien', 'internal/clients', ' - Klien', 1, '2', 1, 1, 1, 1, 1, 1, 1, 1, NULL, 'Users');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (148, 142, 'Surat', 'internal/letter', ' - Surat', 4, '2', 1, 1, 1, 1, 1, 1, 1, 1, NULL, 'FileText');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (149, 142, 'Dokumen Proyek', 'internal/project-documents', ' - Dokumen Proyek', 3, '2', 1, 1, 1, 1, 1, 1, 1, 1, NULL, 'FolderOpen');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (150, 142, 'Proyek', 'internal/portfolio', ' - Proyek', 2, '2', 1, 1, 1, 1, 1, 1, 1, 1, NULL, 'Database');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (151, 1, 'Posting', NULL, 'Posting', 1, NULL, 1, 1, 1, 1, 1, 1, 1, 0, NULL, NULL);
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (154, 151, 'Article', 'articles', 'Posting - Article', 1, NULL, 1, 1, 1, 1, 1, 1, 1, 0, NULL, NULL);
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (155, 151, 'Category', 'category', 'Posting - Category', 2, NULL, 1, 1, 1, 1, 1, 1, 1, 0, NULL, NULL);
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (156, 1, 'QR Code', 'qr-code', 'Generate QR code dengan logo opsional', 8, 'menu', 1, 1, 1, 1, 1, 0, 0, 1, NULL, 'QrCode');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (157, 1, 'Tools PDF', 'pdf-tools', 'Gabung, potong halaman, edit konten, dan tambah TTD PDF', 9, 'menu', 1, 0, 0, 0, 0, 0, 0, 1, NULL, 'FileStack');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (158, 1, 'AI Photo Filter', 'ai-photo-filter', 'Filter foto massal mirip foto referensi sepenuhnya di browser', 10, 'menu', 1, 0, 0, 0, 0, 0, 0, 1, NULL, 'Images');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (200, 1, 'Marketing Center', 'marketing-center', 'Modul marketing, campaign, dan analytics', 190, 'menu', 1, 1, 1, 1, 1, 1, 1, 1, '', 'Megaphone');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (201, 200, 'Dashboard Marketing', 'marketing-center/dashboard', 'Ringkasan performa marketing', 191, 'menu', 1, 1, 1, 1, 1, 1, 1, 1, '', 'LayoutDashboard');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (202, 200, 'Kontak & Database', 'marketing-center/contacts', 'Kelola kontak dan database prospek', 192, 'menu', 1, 1, 1, 1, 1, 1, 1, 1, '', 'Users');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (203, 200, 'Grup & Segmentasi', 'marketing-center/groups', 'Kelola grup dan segmentasi kontak', 193, 'menu', 1, 1, 1, 1, 1, 1, 1, 1, '', 'UsersRound');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (204, 200, 'Email Marketing', 'marketing-center/email', 'Kelola kampanye email marketing', 194, 'menu', 1, 1, 1, 1, 1, 1, 1, 1, '', 'Mail');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (205, 200, 'WhatsApp Marketing', 'marketing-center/whatsapp', 'Kelola kampanye WhatsApp marketing', 195, 'menu', 1, 1, 1, 1, 1, 1, 1, 1, '', 'MessageCircle');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (206, 200, 'Campaign Management', 'marketing-center/campaigns', 'Kelola seluruh kampanye marketing', 196, 'menu', 1, 1, 1, 1, 1, 1, 1, 1, '', 'Megaphone');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (207, 200, 'Template Pesan', 'marketing-center/templates', 'Kelola template email dan WhatsApp', 197, 'menu', 1, 1, 1, 1, 1, 1, 1, 1, '', 'FileText');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (208, 200, 'Analytics & Reports', 'marketing-center/analytics', 'Laporan dan analisis performa', 198, 'menu', 1, 1, 1, 1, 1, 1, 1, 1, '', 'BarChart3');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (209, 200, 'Integrasi & Pengaturan', 'marketing-center/settings', 'Pengaturan integrasi layanan marketing', 199, 'menu', 1, 1, 1, 1, 1, 1, 1, 1, '', 'Settings');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (300, 1, 'Manajemen Keuangan', 'finance', 'Modul manajemen keuangan perusahaan', 300, 'menu', 1, 1, 1, 1, 1, 0, 0, 1, '', 'Wallet');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (301, 300, 'Dashboard Keuangan', 'finance/dashboard', 'Ringkasan kondisi keuangan', 301, 'menu', 1, 1, 1, 1, 1, 0, 0, 1, '', 'LayoutDashboard');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (302, 300, 'Pemasukan', 'finance/incomes', 'Pencatatan pemasukan perusahaan', 302, 'menu', 1, 1, 1, 1, 1, 0, 0, 1, '', 'ArrowDownLeft');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (303, 300, 'Pengeluaran', 'finance/expenses', 'Pencatatan pengeluaran perusahaan', 303, 'menu', 1, 1, 1, 1, 1, 0, 0, 1, '', 'ArrowUpRight');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (304, 300, 'Penggajian', 'finance/payroll', 'Penggajian karyawan bulanan', 304, 'menu', 1, 1, 1, 1, 1, 0, 0, 1, '', 'Users');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (305, 300, 'Kas dan Rekening', 'finance/cash', 'Kas, bank, dan mutasi rekening', 305, 'menu', 1, 1, 1, 1, 1, 0, 0, 1, '', 'Landmark');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (306, 300, 'Anggaran', 'finance/budgets', 'Anggaran dan realisasi', 306, 'menu', 1, 1, 1, 1, 1, 0, 0, 1, '', 'PieChart');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (307, 300, 'Aset Perusahaan', 'finance/assets', 'Aset tetap dan penyusutan', 307, 'menu', 1, 1, 1, 1, 1, 0, 0, 1, '', 'Package');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (308, 300, 'Utang', 'finance/debts', 'Manajemen utang perusahaan', 308, 'menu', 1, 1, 1, 1, 1, 0, 0, 1, '', 'CreditCard');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (309, 300, 'Piutang', 'finance/receivables', 'Manajemen piutang perusahaan', 309, 'menu', 1, 1, 1, 1, 1, 0, 0, 1, '', 'HandCoins');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (310, 300, 'Akuntansi', 'finance/accounting', 'Pembukuan berpasangan', 310, 'menu', 1, 1, 1, 1, 1, 0, 0, 1, '', 'BookOpen');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (311, 310, 'Chart of Accounts', 'finance/accounts', 'Daftar akun akuntansi', 311, 'menu', 1, 1, 1, 1, 1, 0, 0, 1, '', 'ListTree');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (312, 310, 'Jurnal Umum', 'finance/journals', 'Jurnal transaksi', 312, 'menu', 1, 1, 1, 1, 1, 0, 0, 1, '', 'NotebookPen');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (313, 310, 'Buku Besar', 'finance/ledger', 'Buku besar per akun', 313, 'menu', 1, 1, 1, 1, 1, 0, 0, 1, '', 'BookOpen');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (314, 310, 'Neraca Saldo', 'finance/trial-balance', 'Neraca saldo', 314, 'menu', 1, 1, 1, 1, 1, 0, 0, 1, '', 'Scale');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (315, 300, 'Laporan Keuangan', 'finance/reports', 'Laporan keuangan perusahaan', 315, 'menu', 1, 1, 1, 1, 1, 0, 0, 1, '', 'FileBarChart');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (316, 315, 'Laba Rugi', 'finance/reports/profit-loss', 'Laporan laba rugi', 316, 'menu', 1, 1, 1, 1, 1, 0, 0, 1, '', 'TrendingUp');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (317, 315, 'Neraca', 'finance/reports/balance-sheet', 'Laporan posisi keuangan', 317, 'menu', 1, 1, 1, 1, 1, 0, 0, 1, '', 'Scale');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (318, 315, 'Arus Kas', 'finance/reports/cash-flow', 'Laporan arus kas', 318, 'menu', 1, 1, 1, 1, 1, 0, 0, 1, '', 'Activity');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (319, 315, 'Perubahan Ekuitas', 'finance/reports/equity', 'Laporan perubahan ekuitas', 319, 'menu', 1, 1, 1, 1, 1, 0, 0, 1, '', 'RefreshCcw');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (320, 300, 'Pengaturan Keuangan', 'finance/settings', 'Pengaturan modul keuangan', 320, 'menu', 1, 1, 1, 1, 1, 0, 0, 1, '', 'Settings');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (321, 300, 'Persetujuan', 'finance/approvals', 'Antrian persetujuan transaksi', 321, 'menu', 1, 1, 1, 1, 1, 0, 0, 1, '', 'ClipboardCheck');
INSERT INTO `menu` (`menu_id`, `parent_id`, `title`, `url`, `description`, `menu_order`, `type`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`, `is_active`, `class_active`, `icon`) VALUES (322, 300, 'Audit Keuangan', 'finance/audit', 'Riwayat perubahan keuangan', 322, 'menu', 1, 1, 1, 1, 1, 0, 0, 1, '', 'History');

DROP TABLE IF EXISTS `module_authority`;
CREATE TABLE `module_authority` (
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `is_view` int(11) DEFAULT NULL,
  `is_create` int(11) DEFAULT NULL,
  `is_edit` int(11) DEFAULT NULL,
  `is_delete` int(11) DEFAULT NULL,
  `is_export` int(11) DEFAULT NULL,
  `is_duplicate` int(11) DEFAULT NULL,
  `is_unlock` int(11) DEFAULT NULL,
  PRIMARY KEY (`role_id`,`menu_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 1, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 9, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 10, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 11, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 12, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 14, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 15, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 16, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 122, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 123, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 142, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 147, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 148, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 149, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 150, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 156, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 157, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 158, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 200, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 201, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 202, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 203, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 204, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 205, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 206, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 207, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 208, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 209, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 300, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 301, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 302, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 303, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 304, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 305, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 306, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 307, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 308, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 309, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 310, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 311, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 312, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 313, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 314, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 315, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 316, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 317, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 318, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 319, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 320, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 321, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (1, 322, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 1, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 9, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 10, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 11, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 12, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 14, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 15, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 16, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 122, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 123, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 131, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 142, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 147, 1, 0, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 148, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 149, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 150, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 151, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 154, 1, 1, 1, 1, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 156, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 157, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 158, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 200, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 201, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 202, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 203, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 204, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 205, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 206, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 207, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 208, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 209, 1, 1, 1, 1, 1, 1, 1);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 300, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 301, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 302, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 303, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 304, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 305, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 306, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 307, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 308, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 309, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 310, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 311, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 312, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 313, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 314, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 315, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 316, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 317, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 318, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 319, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 320, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 321, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (7, 322, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 156, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 157, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 158, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 200, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 201, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 202, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 203, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 204, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 205, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 206, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 207, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 208, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 209, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 300, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 301, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 302, 1, 0, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 303, 1, 0, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 304, 1, 0, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 305, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 306, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 307, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 308, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 309, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 310, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 311, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 312, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 313, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 314, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 315, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 316, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 317, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 318, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 319, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 320, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 321, 1, 0, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (8, 322, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 156, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 157, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 158, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 200, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 201, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 202, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 203, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 204, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 205, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 206, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 207, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 208, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 209, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 300, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 301, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 302, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 303, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 304, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 305, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 306, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 307, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 308, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 309, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 310, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 311, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 312, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 313, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 314, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 315, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 316, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 317, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 318, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 319, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 320, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 321, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (9, 322, 1, 1, 1, 1, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 156, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 157, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 158, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 200, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 201, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 202, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 203, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 204, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 205, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 206, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 207, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 208, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 209, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 300, 1, 1, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 301, 1, 1, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 302, 1, 1, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 303, 1, 1, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 304, 1, 1, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 305, 1, 1, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 306, 1, 1, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 307, 1, 1, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 308, 1, 1, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 309, 1, 1, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 310, 1, 1, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 311, 1, 1, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 312, 1, 1, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 313, 1, 1, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 314, 1, 1, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 315, 1, 1, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 316, 1, 1, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 317, 1, 1, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 318, 1, 1, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 319, 1, 1, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 320, 1, 1, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 321, 1, 1, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (10, 322, 1, 1, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 156, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 157, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 158, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 200, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 201, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 202, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 203, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 204, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 205, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 206, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 207, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 208, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 209, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 300, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 301, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 302, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 303, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 304, 1, 1, 1, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 305, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 306, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 307, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 308, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 309, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 310, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 311, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 312, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 313, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 314, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 315, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 316, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 317, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 318, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 319, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 320, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 321, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (11, 322, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 156, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 157, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 158, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 200, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 201, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 202, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 203, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 204, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 205, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 206, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 207, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 208, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 209, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 300, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 301, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 302, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 303, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 304, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 305, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 306, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 307, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 308, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 309, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 310, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 311, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 312, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 313, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 314, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 315, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 316, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 317, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 318, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 319, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 320, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 321, 1, 0, 0, 0, 1, 0, 0);
INSERT INTO `module_authority` (`role_id`, `menu_id`, `is_view`, `is_create`, `is_edit`, `is_delete`, `is_export`, `is_duplicate`, `is_unlock`) VALUES (12, 322, 1, 0, 0, 0, 1, 0, 0);

DROP TABLE IF EXISTS `portfolio`;
CREATE TABLE `portfolio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `client_id` int(11) NOT NULL,
  `portfolio_value` int(11) DEFAULT NULL,
  `project_name` varchar(255) DEFAULT NULL,
  `contract_number` varchar(100) DEFAULT NULL,
  `contract_year` year(4) DEFAULT NULL,
  `contract_start_date` date DEFAULT NULL,
  `contract_end_date` date DEFAULT NULL,
  `status` enum('Pending','In Progress','Completed') DEFAULT 'Pending',
  `date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `image` varchar(255) DEFAULT NULL,
  `ba_nego_file` varchar(255) DEFAULT NULL,
  `other_file` varchar(255) DEFAULT NULL,
  `surat_pesanan_file` varchar(255) DEFAULT NULL,
  `tor_file` varchar(255) DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `portfolio` (`id`, `title`, `client_id`, `portfolio_value`, `project_name`, `contract_number`, `contract_year`, `contract_start_date`, `contract_end_date`, `status`, `date`, `created_at`, `image`, `ba_nego_file`, `other_file`, `surat_pesanan_file`, `tor_file`, `description`) VALUES (1, 'Support Pengembangan & Pemeliharaan Aplikasi Dana Pensiun Telkom', 1, 163000000, 'Support Pengembangan & Pemeliharaan Aplikasi Dana Pensiun Telkom', 'Tel.23/LG 270/JDPT-0203000/2026', 2026, '2026-06-01 00:00:00', '2027-05-31 00:00:00', 'In Progress', '2026-05-11 00:00:00', '2026-06-07 20:12:23', '1780837943160.png', NULL, '1795220928677_bfef6d59.pdf', '1795220928677_da3c7d68.pdf', '1795220928674_0f7aad83.pdf', '<table style="border: 1px solid #000;"><tbody><tr><td data-row="1" style="text-align: center;"><strong style="background-color: rgb(251, 228, 213); color: black;">No</strong></td><td data-row="1" style="text-align: center;"><strong style="background-color: rgb(251, 228, 213); color: black;">Kategori&nbsp;Pekerjaan</strong></td><td data-row="1" style="text-align: center;"><strong style="background-color: rgb(251, 228, 213); color: black;">Deskripsi&nbsp;Singkat</strong></td></tr><tr><td data-row="2" style="text-align: center;"><strong style="color: black;">1</strong></td><td data-row="2"><strong style="color: black;">Support&nbsp;Pengembangan&nbsp;Aplikasi&nbsp;</strong></td><td data-row="2"><span style="color: black;">Dukungan&nbsp;pengembangan,&nbsp;pengujian,&nbsp;dokumentasi,&nbsp;deployment,&nbsp;integrasi,&nbsp;dan&nbsp;pelaporan&nbsp;teknis&nbsp;</span></td></tr><tr><td data-row="3"><span style="color: black;">&nbsp;</span></td><td data-row="3"><span style="color: black;">a.&nbsp;Manajemen&nbsp;Lingkungan</span></td><td data-row="3"><span style="color: black;">Konfigurasi&nbsp;&amp;&nbsp;pemeliharaan&nbsp;environment</span></td></tr><tr><td data-row="4"><span style="color: black;">&nbsp;</span></td><td data-row="4"><span style="color: black;">b.&nbsp;Pengujian&nbsp;&amp;&nbsp;QA</span></td><td data-row="4"><span style="color: black;">UAT,&nbsp;integrasi,&nbsp;bug&nbsp;fixing</span></td></tr><tr><td data-row="5"><span style="color: black;">&nbsp;</span></td><td data-row="5"><span style="color: black;">c.&nbsp;Versi&nbsp;&amp;&nbsp;Deployment</span></td><td data-row="5"><span style="color: black;">Build,&nbsp;versioning,&nbsp;release&nbsp;ke&nbsp;production</span></td></tr><tr><td data-row="6"><span style="color: black;">&nbsp;</span></td><td data-row="6"><span style="color: black;">d.&nbsp;Integrasi&nbsp;Sistem</span></td><td data-row="6"><span style="color: black;">Interkoneksi&nbsp;dengan&nbsp;sistem&nbsp;eksisting</span></td></tr><tr><td data-row="7"><span style="color: black;">&nbsp;</span></td><td data-row="7"><span style="color: black;">e.&nbsp;Dokumentasi&nbsp;Teknis</span></td><td data-row="7"><span style="color: black;">API&nbsp;docs,&nbsp;arsitektur,&nbsp;panduan&nbsp;teknis</span></td></tr><tr><td data-row="8"><span style="color: black;">&nbsp;</span></td><td data-row="8"><span style="color: black;">f.&nbsp;Laporan&nbsp;Pekerjaan</span></td><td data-row="8"><span style="color: black;">Laporan&nbsp;berkala&nbsp;dan&nbsp;dokumentasi&nbsp;kegiatan</span></td></tr><tr><td data-row="9" style="text-align: center;"><strong style="color: black;">2</strong></td><td data-row="9"><strong style="color: black;">Support&nbsp;Pemeliharaan&nbsp;Aplikasi</strong></td><td data-row="9"><span style="color: black;">Penanganan&nbsp;insiden,&nbsp;monitoring&nbsp;sistem,&nbsp;pemeliharaan&nbsp;rutin,&nbsp;dan&nbsp;dukungan&nbsp;pengguna</span></td></tr><tr><td data-row="10"><span style="color: black;">&nbsp;</span></td><td data-row="10"><span style="color: black;">a.&nbsp;Insiden&nbsp;&amp;&nbsp;Troubleshooting</span></td><td data-row="10"><span style="color: black;">Penanganan&nbsp;masalah,&nbsp;workaround,&nbsp;eskalasi</span></td></tr><tr><td data-row="11"><span style="color: black;">&nbsp;</span></td><td data-row="11"><span style="color: black;">b.&nbsp;Pemeliharaan&nbsp;Rutin</span></td><td data-row="11"><span style="color: black;">Monitoring&nbsp;sistem,&nbsp;patching,&nbsp;archiving</span></td></tr><tr><td data-row="12"><span style="color: black;">&nbsp;</span></td><td data-row="12"><span style="color: black;">c.&nbsp;Manajemen&nbsp;Perubahan&nbsp;Minor</span></td><td data-row="12"><span style="color: black;">Konfigurasi&nbsp;kecil,&nbsp;update&nbsp;minor,&nbsp;dokumentasi&nbsp;perubahan</span></td></tr><tr><td data-row="13"><span style="color: black;">&nbsp;</span></td><td data-row="13"><span style="color: black;">d.&nbsp;Dukungan&nbsp;Pengguna</span></td><td data-row="13"><span style="color: black;">User&nbsp;support,&nbsp;knowledge&nbsp;base,&nbsp;dokumentasi&nbsp;panduan</span></td></tr><tr><td data-row="14"><span style="color: black;">&nbsp;</span></td><td data-row="14"><span style="color: black;">e.&nbsp;Laporan&nbsp;Aktivitas</span></td><td data-row="14"><span style="color: black;">Rekap&nbsp;insiden,&nbsp;kinerja&nbsp;sistem,&nbsp;dan&nbsp;laporan&nbsp;maintenance&nbsp;lainnya</span></td></tr></tbody></table>');
INSERT INTO `portfolio` (`id`, `title`, `client_id`, `portfolio_value`, `project_name`, `contract_number`, `contract_year`, `contract_start_date`, `contract_end_date`, `status`, `date`, `created_at`, `image`, `ba_nego_file`, `other_file`, `surat_pesanan_file`, `tor_file`, `description`) VALUES (2, 'Jasa Peningkatan Keamanan Siber untuk Public Web Dana Pensiun Telkom', 1, 66891892, 'Jasa Peningkatan Keamanan Siber untuk Public Web Dana Pensiun Telkom', '1424/LG-29/Dapentel-012/2026', 2026, '2026-11-01 00:00:00', '2026-11-30 00:00:00', 'Pending', '2026-11-04 00:00:00', '2026-11-05 11:23:53', NULL, NULL, NULL, NULL, NULL, '<p>-</p>');

DROP TABLE IF EXISTS `project_documents`;
CREATE TABLE `project_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inspection_date` date DEFAULT NULL,
  `inspection_officer_name_1` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inspection_officer_role_1` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inspection_officer_name_2` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inspection_officer_role_2` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inspection_description` text COLLATE utf8mb4_unicode_ci,
  `progress_date` date DEFAULT NULL,
  `progress_officer_name_1` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `progress_officer_role_1` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `progress_officer_name_2` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `progress_officer_role_2` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `progress_description` text COLLATE utf8mb4_unicode_ci,
  `handover_date` date DEFAULT NULL,
  `handover_officer_name_1` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `handover_officer_role_1` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `handover_officer_name_2` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `handover_officer_role_2` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `handover_description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `company_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `progress_status` int(11) DEFAULT NULL,
  `handover_status` int(11) DEFAULT NULL,
  `bapp_attachment` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `fk_project_document` (`project_id`),
  CONSTRAINT `fk_project_document` FOREIGN KEY (`project_id`) REFERENCES `portfolio` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `project_documents` (`id`, `project_id`, `location`, `inspection_date`, `inspection_officer_name_1`, `inspection_officer_role_1`, `inspection_officer_name_2`, `inspection_officer_role_2`, `inspection_description`, `progress_date`, `progress_officer_name_1`, `progress_officer_role_1`, `progress_officer_name_2`, `progress_officer_role_2`, `progress_description`, `handover_date`, `handover_officer_name_1`, `handover_officer_role_1`, `handover_officer_name_2`, `handover_officer_role_2`, `handover_description`, `created_at`, `updated_at`, `company_1`, `company_2`, `progress_status`, `handover_status`, `bapp_attachment`) VALUES (1, 1, 'Dana Pensiun Telkom', '2026-06-24 00:00:00', 'Bambang Gunawan H', 'Manager Information System', 'Nava Gia Ginasta, M.Kom', 'Direktur Utama', '<p style="text-align: justify;">Bahwa&nbsp;<strong>PIHAK&nbsp;KEDUA&nbsp;</strong>telah&nbsp;menyelesaikan&nbsp;pekerjaan&nbsp;<em>Support&nbsp;</em>Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom&nbsp;2026&nbsp;yang&nbsp;sesuai&nbsp;dengan&nbsp;Kontrak&nbsp;nomor:&nbsp;121/HK-71/Dapentel-020/2026&nbsp;periode&nbsp;Juni&nbsp;2026&nbsp;yang&nbsp;telah&nbsp;sesuai&nbsp;dengan&nbsp;TOR&nbsp;dengan&nbsp;detail&nbsp;sebagai&nbsp;berikut:</p><ol><li>Support&nbsp;Pengembanan&nbsp;Aplikasi.</li><li>Support&nbsp;Pemeliharaan&nbsp;Aplikasi.</li></ol><p style="text-align: justify;">Detil&nbsp;dari&nbsp;pekerjaan&nbsp;tersebut&nbsp;terlampir&nbsp;pada&nbsp;Dokumen&nbsp;Laporan&nbsp;Pekerjaan&nbsp;atau&nbsp;dapat&nbsp;diakses&nbsp;melalui&nbsp;link&nbsp;<a href="https://bit.ly/DapenCrop2026" rel="noopener noreferrer" target="_blank" style="color: black;">https://bit.ly/DapenCrop2026</a>.</p><p style="text-align: justify;"><strong>PIHAK&nbsp;PERTAMA&nbsp;</strong>telah&nbsp;menerima&nbsp;hasil&nbsp;pelaksanaan&nbsp;pekerjaan&nbsp;berupa&nbsp;lampiran&nbsp;tersebut&nbsp;diatas&nbsp;hasil&nbsp;dari&nbsp;<em>Support&nbsp;</em>Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom&nbsp;2026&nbsp;yang&nbsp;sesuai&nbsp;dengan&nbsp;Kontrak&nbsp;nomor:&nbsp;121/HK-71/Dapentel-020/2026&nbsp;periode&nbsp;Juni&nbsp;2026.</p><p style="text-align: justify;"></p><p style="text-align: justify;">Demikian&nbsp;berita&nbsp;acara&nbsp;pekerjaan&nbsp;(BAP)&nbsp;ini&nbsp;dibuat&nbsp;untuk&nbsp;dipergunakan&nbsp;sebagaimana&nbsp;mestinya.</p>', '2026-05-23 00:00:00', 'Angkoso Suryocahyono', 'PGS VP Information System & Reporting', 'Nava Gia Ginasta, M.Kom', 'Direktur Utama', '<p>Berdasarkan&nbsp;Kontrak&nbsp;Perjanjian&nbsp;Kerja&nbsp;Sama&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;Nomor:&nbsp;<strong>Tel.23/LG&nbsp;270/JDPT-0203000/2026</strong>&nbsp;tanggal&nbsp;<strong>11&nbsp;Mei&nbsp;2026</strong></p><p>Dengan&nbsp;ini&nbsp;menerangkan&nbsp;bahwa:</p><ol><li><strong>PIHAK&nbsp;KEDUA</strong>&nbsp;menyatakan&nbsp;telah&nbsp;menyelesaikan&nbsp;pekerjaan&nbsp;sesuai&nbsp;ruang&nbsp;lingkup&nbsp;dan&nbsp;deliverables&nbsp;pengadaan&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;sesuai&nbsp;dengan&nbsp;Kontrak&nbsp;Perjanjian&nbsp;Kerja&nbsp;Sama&nbsp;Nomor:&nbsp;<strong>Tel.23/LG&nbsp;270/JDPT-0203000/2026</strong></li><li><strong>PIHAK&nbsp;PERTAMA</strong>&nbsp;menyatakan&nbsp;telah&nbsp;memeriksa&nbsp;hasil&nbsp;pekerjaan&nbsp;dan&nbsp;deliverables&nbsp;dimaksud&nbsp;pada&nbsp;butir&nbsp;1&nbsp;dengan&nbsp;hasil&nbsp;Baik&nbsp;dan&nbsp;Sesuai.</li><li>Laporan&nbsp;hasil&nbsp;dan/atau&nbsp;checklist&nbsp;penyelesaian&nbsp;pekerjaan&nbsp;sebagaimana&nbsp;terlampir.</li></ol><p>Demikian&nbsp;Berita&nbsp;Acara&nbsp;Penyelesaian&nbsp;Pekerjaan&nbsp;(BAPP)&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;ini&nbsp;dibuat&nbsp;dalam&nbsp;rangkap&nbsp;2&nbsp;(dua)&nbsp;asli,&nbsp;masing-masing&nbsp;sama&nbsp;bunyinya&nbsp;serta&nbsp;mempunyai&nbsp;kekuatan&nbsp;hukum&nbsp;yang&nbsp;sama&nbsp;setelah&nbsp;ditandatangani&nbsp;kedua&nbsp;belah&nbsp;pihak&nbsp;untuk&nbsp;dipergunakan&nbsp;sebagaimana&nbsp;mestinya.</p>', '2026-05-29 00:00:00', 'M.Arief Widhiyanto', 'SM HCM & Logistic', 'Nava Gia Ginasta, M.Kom', 'Direktur Utama', '<p>Berdasarkan:</p><ol><li>Kontrak&nbsp;Perjanjian&nbsp;Kerja&nbsp;Sama&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;Nomor:&nbsp;<strong>Tel.23/LG&nbsp;270/JDPT-0203000/2026</strong>&nbsp;tanggal&nbsp;<strong>11&nbsp;Mei&nbsp;2026</strong></li><li>Amandemen&nbsp;Kesatu&nbsp;Kontrak&nbsp;Perjanjian&nbsp;Kerja&nbsp;Sama&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;Nomor:&nbsp;<strong>Tel.23/LG&nbsp;270/JDPT-0203000/2026</strong>&nbsp;tanggal&nbsp;<strong>11&nbsp;Mei&nbsp;2026</strong></li><li>Berita&nbsp;Acara&nbsp;Penyelesaian&nbsp;Pekerjaan&nbsp;(BAPP)&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;Nomor:&nbsp;<strong>Tel.23/LG&nbsp;270/JDPT-0203000/2026</strong>&nbsp;tanggal&nbsp;<strong>11&nbsp;Mei&nbsp;2026</strong></li></ol><p>Dengan&nbsp;ini&nbsp;menyatakan&nbsp;bahwa:</p><ol><li>1.&nbsp;&nbsp;&nbsp;&nbsp;<strong>PIHAK&nbsp;KEDUA</strong>&nbsp;menyerahkan&nbsp;seluruh&nbsp;hasil&nbsp;pekerjaan&nbsp;dan&nbsp;deliverables&nbsp;sesuai&nbsp;dengan&nbsp;dokumen&nbsp;tersebut&nbsp;di&nbsp;atas&nbsp;kepada&nbsp;<strong>PIHAK&nbsp;PERTAMA</strong>.</li><li>2.&nbsp;&nbsp;&nbsp;&nbsp;<strong>PIHAK&nbsp;PERTAMA</strong>&nbsp;menerima&nbsp;seluruh&nbsp;hasil&nbsp;pekerjaan&nbsp;dan&nbsp;deliverables&nbsp;sesuai&nbsp;sesuai&nbsp;dengan&nbsp;dokumen&nbsp;tersebut&nbsp;di&nbsp;atas&nbsp;dari&nbsp;<strong>PIHAK&nbsp;KEDUA</strong>.</li></ol><p>Demikian&nbsp;Berita&nbsp;Acara&nbsp;Serah&nbsp;Terima&nbsp;Pekerjaan&nbsp;(BAST)&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;ini&nbsp;dibuat&nbsp;dalam&nbsp;rangkap&nbsp;2&nbsp;(dua)&nbsp;asli,&nbsp;masing-masing&nbsp;sama&nbsp;bunyinya&nbsp;serta&nbsp;mempunyai&nbsp;kekuatan&nbsp;hukum&nbsp;yang&nbsp;sama&nbsp;setelah&nbsp;ditandatangani&nbsp;kedua&nbsp;belah&nbsp;pihak&nbsp;untuk&nbsp;dipergunakan&nbsp;sebagaimana&nbsp;mestinya.</p>', '2026-06-07 21:09:49', '2026-07-03 15:37:52', 'Dana Pensiun Telkom', 'PT Crop Inspirasi Digital', 0, 0, NULL);
INSERT INTO `project_documents` (`id`, `project_id`, `location`, `inspection_date`, `inspection_officer_name_1`, `inspection_officer_role_1`, `inspection_officer_name_2`, `inspection_officer_role_2`, `inspection_description`, `progress_date`, `progress_officer_name_1`, `progress_officer_role_1`, `progress_officer_name_2`, `progress_officer_role_2`, `progress_description`, `handover_date`, `handover_officer_name_1`, `handover_officer_role_1`, `handover_officer_name_2`, `handover_officer_role_2`, `handover_description`, `created_at`, `updated_at`, `company_1`, `company_2`, `progress_status`, `handover_status`, `bapp_attachment`) VALUES (2, 1, 'Dana Pensiun Telkom', '2026-07-27 00:00:00', 'Bambang Gunawan H', 'Manager Information System', 'Nava Gia Ginasta, M.Kom', 'Direktur Utama', '<p style="text-align: justify;">Bahwa&nbsp;<strong>PIHAK&nbsp;KEDUA&nbsp;</strong>telah&nbsp;menyelesaikan&nbsp;pekerjaan&nbsp;<em>Support&nbsp;</em>Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom&nbsp;2026&nbsp;yang&nbsp;sesuai&nbsp;dengan&nbsp;Kontrak&nbsp;nomor:&nbsp;121/HK-71/Dapentel-020/2026&nbsp;periode&nbsp;Juli&nbsp;2026&nbsp;yang&nbsp;telah&nbsp;sesuai&nbsp;dengan&nbsp;TOR&nbsp;dengan&nbsp;detail&nbsp;sebagai&nbsp;berikut:</p><ol><li>Support&nbsp;Pengembanan&nbsp;Aplikasi.</li><li>Support&nbsp;Pemeliharaan&nbsp;Aplikasi.</li></ol><p style="text-align: justify;">Detil&nbsp;dari&nbsp;pekerjaan&nbsp;tersebut&nbsp;terlampir&nbsp;pada&nbsp;Dokumen&nbsp;Laporan&nbsp;Pekerjaan&nbsp;atau&nbsp;dapat&nbsp;diakses&nbsp;melalui&nbsp;link&nbsp;<a href="https://bit.ly/DapenCrop2026" rel="noopener noreferrer" target="_blank" style="color: black;">https://bit.ly/DapenCrop2026</a>.</p><p style="text-align: justify;"><strong>PIHAK&nbsp;PERTAMA&nbsp;</strong>telah&nbsp;menerima&nbsp;hasil&nbsp;pelaksanaan&nbsp;pekerjaan&nbsp;berupa&nbsp;lampiran&nbsp;tersebut&nbsp;diatas&nbsp;hasil&nbsp;dari&nbsp;<em>Support&nbsp;</em>Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom&nbsp;2026&nbsp;yang&nbsp;sesuai&nbsp;dengan&nbsp;Kontrak&nbsp;nomor:&nbsp;121/HK-71/Dapentel-020/2026&nbsp;periode&nbsp;Juli&nbsp;2026.</p><p style="text-align: justify;"></p><p style="text-align: justify;">Demikian&nbsp;berita&nbsp;acara&nbsp;pekerjaan&nbsp;(BAP)&nbsp;ini&nbsp;dibuat&nbsp;untuk&nbsp;dipergunakan&nbsp;sebagaimana&nbsp;mestinya.</p>', '2026-07-17 00:00:00', 'Angkoso Suryocahyono', 'PGS VP Information System & Reporting', 'Nava Gia Ginasta, M.Kom', 'Direktur Utama', '<p>Berdasarkan&nbsp;Kontrak&nbsp;Perjanjian&nbsp;Kerja&nbsp;Sama&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;Nomor:&nbsp;<strong>Tel.23/LG&nbsp;270/JDPT-0203000/2026</strong>&nbsp;tanggal&nbsp;<strong>11&nbsp;Mei&nbsp;2026</strong></p><p>Dengan&nbsp;ini&nbsp;menerangkan&nbsp;bahwa:</p><ol><li><strong>PIHAK&nbsp;KEDUA</strong>&nbsp;menyatakan&nbsp;telah&nbsp;menyelesaikan&nbsp;pekerjaan&nbsp;sesuai&nbsp;ruang&nbsp;lingkup&nbsp;dan&nbsp;deliverables&nbsp;pengadaan&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;sesuai&nbsp;dengan&nbsp;Kontrak&nbsp;Perjanjian&nbsp;Kerja&nbsp;Sama&nbsp;Nomor:&nbsp;<strong>Tel.23/LG&nbsp;270/JDPT-0203000/2026</strong></li><li><strong>PIHAK&nbsp;PERTAMA</strong>&nbsp;menyatakan&nbsp;telah&nbsp;memeriksa&nbsp;hasil&nbsp;pekerjaan&nbsp;dan&nbsp;deliverables&nbsp;dimaksud&nbsp;pada&nbsp;butir&nbsp;1&nbsp;dengan&nbsp;hasil&nbsp;Baik&nbsp;dan&nbsp;Sesuai.</li><li>Laporan&nbsp;hasil&nbsp;dan/atau&nbsp;checklist&nbsp;penyelesaian&nbsp;pekerjaan&nbsp;sebagaimana&nbsp;terlampir.</li></ol><p>Demikian&nbsp;Berita&nbsp;Acara&nbsp;Penyelesaian&nbsp;Pekerjaan&nbsp;(BAPP)&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;ini&nbsp;dibuat&nbsp;dalam&nbsp;rangkap&nbsp;2&nbsp;(dua)&nbsp;asli,&nbsp;masing-masing&nbsp;sama&nbsp;bunyinya&nbsp;serta&nbsp;mempunyai&nbsp;kekuatan&nbsp;hukum&nbsp;yang&nbsp;sama&nbsp;setelah&nbsp;ditandatangani&nbsp;kedua&nbsp;belah&nbsp;pihak&nbsp;untuk&nbsp;dipergunakan&nbsp;sebagaimana&nbsp;mestinya.</p>', '2026-07-17 00:00:00', 'M.Arief Widhiyanto', 'SM HCM & Logistic', 'Nava Gia Ginasta, M.Kom', 'Direktur Utama', '<p>Berdasarkan:</p><ol><li>Kontrak&nbsp;Perjanjian&nbsp;Kerja&nbsp;Sama&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;Nomor:&nbsp;<strong>Tel.23/LG&nbsp;270/JDPT-0203000/2026</strong>&nbsp;tanggal&nbsp;<strong>11&nbsp;Mei&nbsp;2026</strong></li><li>Amandemen&nbsp;Kesatu&nbsp;Kontrak&nbsp;Perjanjian&nbsp;Kerja&nbsp;Sama&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;Nomor:&nbsp;<strong>Tel.23/LG&nbsp;270/JDPT-0203000/2026</strong>&nbsp;tanggal&nbsp;<strong>11&nbsp;Mei&nbsp;2026</strong></li><li>Berita&nbsp;Acara&nbsp;Penyelesaian&nbsp;Pekerjaan&nbsp;(BAPP)&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;Nomor:&nbsp;<strong>Tel.23/LG&nbsp;270/JDPT-0203000/2026</strong>&nbsp;tanggal&nbsp;<strong>11&nbsp;Mei&nbsp;2026</strong></li></ol><p>Dengan&nbsp;ini&nbsp;menyatakan&nbsp;bahwa:</p><ol><li>1.&nbsp;&nbsp;&nbsp;&nbsp;<strong>PIHAK&nbsp;KEDUA</strong>&nbsp;menyerahkan&nbsp;seluruh&nbsp;hasil&nbsp;pekerjaan&nbsp;dan&nbsp;deliverables&nbsp;sesuai&nbsp;dengan&nbsp;dokumen&nbsp;tersebut&nbsp;di&nbsp;atas&nbsp;kepada&nbsp;<strong>PIHAK&nbsp;PERTAMA</strong>.</li><li>2.&nbsp;&nbsp;&nbsp;&nbsp;<strong>PIHAK&nbsp;PERTAMA</strong>&nbsp;menerima&nbsp;seluruh&nbsp;hasil&nbsp;pekerjaan&nbsp;dan&nbsp;deliverables&nbsp;sesuai&nbsp;sesuai&nbsp;dengan&nbsp;dokumen&nbsp;tersebut&nbsp;di&nbsp;atas&nbsp;dari&nbsp;<strong>PIHAK&nbsp;KEDUA</strong>.</li></ol><p>Demikian&nbsp;Berita&nbsp;Acara&nbsp;Serah&nbsp;Terima&nbsp;Pekerjaan&nbsp;(BAST)&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;ini&nbsp;dibuat&nbsp;dalam&nbsp;rangkap&nbsp;2&nbsp;(dua)&nbsp;asli,&nbsp;masing-masing&nbsp;sama&nbsp;bunyinya&nbsp;serta&nbsp;mempunyai&nbsp;kekuatan&nbsp;hukum&nbsp;yang&nbsp;sama&nbsp;setelah&nbsp;ditandatangani&nbsp;kedua&nbsp;belah&nbsp;pihak&nbsp;untuk&nbsp;dipergunakan&nbsp;sebagaimana&nbsp;mestinya.</p>', '2026-07-22 11:50:31', '2026-07-22 12:16:32', 'Dana Pensiun Telkom', 'PT Crop Inspirasi Digital', 0, 0, NULL);
INSERT INTO `project_documents` (`id`, `project_id`, `location`, `inspection_date`, `inspection_officer_name_1`, `inspection_officer_role_1`, `inspection_officer_name_2`, `inspection_officer_role_2`, `inspection_description`, `progress_date`, `progress_officer_name_1`, `progress_officer_role_1`, `progress_officer_name_2`, `progress_officer_role_2`, `progress_description`, `handover_date`, `handover_officer_name_1`, `handover_officer_role_1`, `handover_officer_name_2`, `handover_officer_role_2`, `handover_description`, `created_at`, `updated_at`, `company_1`, `company_2`, `progress_status`, `handover_status`, `bapp_attachment`) VALUES (3, 1, 'Dana Pensiun Telkom', '2026-08-27 00:00:00', 'Bambang Gunawan H', 'Manager Information System', 'Nava Gia Ginasta, M.Kom', 'Direktur Utama', '<p style="text-align: justify;">Bahwa&nbsp;<strong>PIHAK&nbsp;KEDUA&nbsp;</strong>telah&nbsp;menyelesaikan&nbsp;pekerjaan&nbsp;<em>Support&nbsp;</em>Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom&nbsp;2026&nbsp;yang&nbsp;sesuai&nbsp;dengan&nbsp;Kontrak&nbsp;nomor:&nbsp;121/HK-71/Dapentel-020/2026&nbsp;periode&nbsp;Agustus&nbsp;2026&nbsp;yang&nbsp;telah&nbsp;sesuai&nbsp;dengan&nbsp;TOR&nbsp;dengan&nbsp;detail&nbsp;sebagai&nbsp;berikut:</p><ol><li>Support&nbsp;Pengembangan&nbsp;Aplikasi.</li><li>Support&nbsp;Pemeliharaan&nbsp;Aplikasi.</li></ol><p style="text-align: justify;">Detil&nbsp;dari&nbsp;pekerjaan&nbsp;tersebut&nbsp;terlampir&nbsp;pada&nbsp;Dokumen&nbsp;Laporan&nbsp;Pekerjaan&nbsp;atau&nbsp;dapat&nbsp;diakses&nbsp;melalui&nbsp;link&nbsp;<a href="https://bit.ly/DapenCrop2026" rel="noopener noreferrer" target="_blank" style="color: black;">https://bit.ly/DapenCrop2026</a>.</p><p style="text-align: justify;"><strong>PIHAK&nbsp;PERTAMA&nbsp;</strong>telah&nbsp;menerima&nbsp;hasil&nbsp;pelaksanaan&nbsp;pekerjaan&nbsp;berupa&nbsp;lampiran&nbsp;tersebut&nbsp;diatas&nbsp;hasil&nbsp;dari&nbsp;<em>Support&nbsp;</em>Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom&nbsp;2026&nbsp;yang&nbsp;sesuai&nbsp;dengan&nbsp;Kontrak&nbsp;nomor:&nbsp;121/HK-71/Dapentel-020/2026&nbsp;periode&nbsp;Agustus&nbsp;2026.</p><p style="text-align: justify;"></p><p style="text-align: justify;">Demikian&nbsp;berita&nbsp;acara&nbsp;pekerjaan&nbsp;(BAP)&nbsp;ini&nbsp;dibuat&nbsp;untuk&nbsp;dipergunakan&nbsp;sebagaimana&nbsp;mestinya.</p>', '2026-08-20 00:00:00', 'Angkoso Suryocahyono', 'PGS VP Information System & Reporting', 'Nava Gia Ginasta, M.Kom', 'Direktur Utama', '<p>Berdasarkan&nbsp;Kontrak&nbsp;Perjanjian&nbsp;Kerja&nbsp;Sama&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;Nomor:&nbsp;<strong>Tel.23/LG&nbsp;270/JDPT-0203000/2026</strong>&nbsp;tanggal&nbsp;<strong>11&nbsp;Mei&nbsp;2026</strong></p><p>Dengan&nbsp;ini&nbsp;menerangkan&nbsp;bahwa:</p><ol><li><strong>PIHAK&nbsp;KEDUA</strong>&nbsp;menyatakan&nbsp;telah&nbsp;menyelesaikan&nbsp;pekerjaan&nbsp;sesuai&nbsp;ruang&nbsp;lingkup&nbsp;dan&nbsp;deliverables&nbsp;pengadaan&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;sesuai&nbsp;dengan&nbsp;Kontrak&nbsp;Perjanjian&nbsp;Kerja&nbsp;Sama&nbsp;Nomor:&nbsp;<strong>Tel.23/LG&nbsp;270/JDPT-0203000/2026</strong></li><li><strong>PIHAK&nbsp;PERTAMA</strong>&nbsp;menyatakan&nbsp;telah&nbsp;memeriksa&nbsp;hasil&nbsp;pekerjaan&nbsp;dan&nbsp;deliverables&nbsp;dimaksud&nbsp;pada&nbsp;butir&nbsp;1&nbsp;dengan&nbsp;hasil&nbsp;Baik&nbsp;dan&nbsp;Sesuai.</li><li>Laporan&nbsp;hasil&nbsp;dan/atau&nbsp;checklist&nbsp;penyelesaian&nbsp;pekerjaan&nbsp;sebagaimana&nbsp;terlampir.</li></ol><p>Demikian&nbsp;Berita&nbsp;Acara&nbsp;Penyelesaian&nbsp;Pekerjaan&nbsp;(BAPP)&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;ini&nbsp;dibuat&nbsp;dalam&nbsp;rangkap&nbsp;2&nbsp;(dua)&nbsp;asli,&nbsp;masing-masing&nbsp;sama&nbsp;bunyinya&nbsp;serta&nbsp;mempunyai&nbsp;kekuatan&nbsp;hukum&nbsp;yang&nbsp;sama&nbsp;setelah&nbsp;ditandatangani&nbsp;kedua&nbsp;belah&nbsp;pihak&nbsp;untuk&nbsp;dipergunakan&nbsp;sebagaimana&nbsp;mestinya.</p>', '2026-08-20 00:00:00', 'M.Arief Widhiyanto', 'SM HCM & Logistic', 'Nava Gia Ginasta, M.Kom', 'Direktur Utama', '<p>Berdasarkan:</p><ol><li>Kontrak&nbsp;Perjanjian&nbsp;Kerja&nbsp;Sama&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;Nomor:&nbsp;<strong>Tel.23/LG&nbsp;270/JDPT-0203000/2026</strong>&nbsp;tanggal&nbsp;<strong>11&nbsp;Mei&nbsp;2026</strong></li><li>Amandemen&nbsp;Kesatu&nbsp;Kontrak&nbsp;Perjanjian&nbsp;Kerja&nbsp;Sama&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;Nomor:&nbsp;<strong>Tel.23/LG&nbsp;270/JDPT-0203000/2026</strong>&nbsp;tanggal&nbsp;<strong>11&nbsp;Mei&nbsp;2026</strong></li><li>Berita&nbsp;Acara&nbsp;Penyelesaian&nbsp;Pekerjaan&nbsp;(BAPP)&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;Nomor:&nbsp;<strong>Tel.23/LG&nbsp;270/JDPT-0203000/2026</strong>&nbsp;tanggal&nbsp;<strong>11&nbsp;Mei&nbsp;2026</strong></li></ol><p>Dengan&nbsp;ini&nbsp;menyatakan&nbsp;bahwa:</p><ol><li>1.&nbsp;&nbsp;&nbsp;&nbsp;<strong>PIHAK&nbsp;KEDUA</strong>&nbsp;menyerahkan&nbsp;seluruh&nbsp;hasil&nbsp;pekerjaan&nbsp;dan&nbsp;deliverables&nbsp;sesuai&nbsp;dengan&nbsp;dokumen&nbsp;tersebut&nbsp;di&nbsp;atas&nbsp;kepada&nbsp;<strong>PIHAK&nbsp;PERTAMA</strong>.</li><li>2.&nbsp;&nbsp;&nbsp;&nbsp;<strong>PIHAK&nbsp;PERTAMA</strong>&nbsp;menerima&nbsp;seluruh&nbsp;hasil&nbsp;pekerjaan&nbsp;dan&nbsp;deliverables&nbsp;sesuai&nbsp;sesuai&nbsp;dengan&nbsp;dokumen&nbsp;tersebut&nbsp;di&nbsp;atas&nbsp;dari&nbsp;<strong>PIHAK&nbsp;KEDUA</strong>.</li></ol><p>Demikian&nbsp;Berita&nbsp;Acara&nbsp;Serah&nbsp;Terima&nbsp;Pekerjaan&nbsp;(BAST)&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;ini&nbsp;dibuat&nbsp;dalam&nbsp;rangkap&nbsp;2&nbsp;(dua)&nbsp;asli,&nbsp;masing-masing&nbsp;sama&nbsp;bunyinya&nbsp;serta&nbsp;mempunyai&nbsp;kekuatan&nbsp;hukum&nbsp;yang&nbsp;sama&nbsp;setelah&nbsp;ditandatangani&nbsp;kedua&nbsp;belah&nbsp;pihak&nbsp;untuk&nbsp;dipergunakan&nbsp;sebagaimana&nbsp;mestinya.</p>', '2026-08-26 14:03:15', '2026-08-28 17:29:12', 'Dana Pensiun Telkom', 'PT Crop Inspirasi Digital', 0, 0, NULL);
INSERT INTO `project_documents` (`id`, `project_id`, `location`, `inspection_date`, `inspection_officer_name_1`, `inspection_officer_role_1`, `inspection_officer_name_2`, `inspection_officer_role_2`, `inspection_description`, `progress_date`, `progress_officer_name_1`, `progress_officer_role_1`, `progress_officer_name_2`, `progress_officer_role_2`, `progress_description`, `handover_date`, `handover_officer_name_1`, `handover_officer_role_1`, `handover_officer_name_2`, `handover_officer_role_2`, `handover_description`, `created_at`, `updated_at`, `company_1`, `company_2`, `progress_status`, `handover_status`, `bapp_attachment`) VALUES (4, 1, 'Dana Pensiun Telkom', '2026-09-26 00:00:00', 'Bambang Gunawan H', 'Manager Information System', 'Nava Gia Ginasta, M.Kom', 'Direktur Utama', '<p style="text-align: justify;">Bahwa&nbsp;<strong>PIHAK&nbsp;KEDUA&nbsp;</strong>telah&nbsp;menyelesaikan&nbsp;pekerjaan&nbsp;<em>Support&nbsp;</em>Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom&nbsp;2026&nbsp;yang&nbsp;sesuai&nbsp;dengan&nbsp;Kontrak&nbsp;nomor:&nbsp;121/HK-71/Dapentel-020/2026&nbsp;periode&nbsp;September&nbsp;2026&nbsp;yang&nbsp;telah&nbsp;sesuai&nbsp;dengan&nbsp;TOR&nbsp;dengan&nbsp;detail&nbsp;sebagai&nbsp;berikut:</p><ol><li>Support&nbsp;Pengembangan&nbsp;Aplikasi.</li><li>Support&nbsp;Pemeliharaan&nbsp;Aplikasi.</li></ol><p style="text-align: justify;">Detil&nbsp;dari&nbsp;pekerjaan&nbsp;tersebut&nbsp;terlampir&nbsp;pada&nbsp;Dokumen&nbsp;Laporan&nbsp;Pekerjaan&nbsp;atau&nbsp;dapat&nbsp;diakses&nbsp;melalui&nbsp;link&nbsp;<a href="https://bit.ly/DapenCrop2026" rel="noopener noreferrer" target="_blank" style="color: black;">https://bit.ly/DapenCrop2026</a>.</p><p style="text-align: justify;"><strong>PIHAK&nbsp;PERTAMA&nbsp;</strong>telah&nbsp;menerima&nbsp;hasil&nbsp;pelaksanaan&nbsp;pekerjaan&nbsp;berupa&nbsp;lampiran&nbsp;tersebut&nbsp;diatas&nbsp;hasil&nbsp;dari&nbsp;<em>Support&nbsp;</em>Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom&nbsp;2026&nbsp;yang&nbsp;sesuai&nbsp;dengan&nbsp;Kontrak&nbsp;nomor:&nbsp;121/HK-71/Dapentel-020/2026&nbsp;periode&nbsp;September&nbsp;2026.</p><p style="text-align: justify;"></p><p style="text-align: justify;">Demikian&nbsp;berita&nbsp;acara&nbsp;pekerjaan&nbsp;(BAP)&nbsp;ini&nbsp;dibuat&nbsp;untuk&nbsp;dipergunakan&nbsp;sebagaimana&nbsp;mestinya.</p>', '2026-09-07 00:00:00', 'Angkoso Suryocahyono', 'PGS VP Information System & Reporting', 'Nava Gia Ginasta, M.Kom', 'Direktur Utama', '<p>Berdasarkan&nbsp;Kontrak&nbsp;Perjanjian&nbsp;Kerja&nbsp;Sama&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;Nomor:&nbsp;<strong>Tel.23/LG&nbsp;270/JDPT-0203000/2026</strong>&nbsp;tanggal&nbsp;<strong>11&nbsp;Mei&nbsp;2026</strong></p><p>Dengan&nbsp;ini&nbsp;menerangkan&nbsp;bahwa:</p><ol><li><strong>PIHAK&nbsp;KEDUA</strong>&nbsp;menyatakan&nbsp;telah&nbsp;menyelesaikan&nbsp;pekerjaan&nbsp;sesuai&nbsp;ruang&nbsp;lingkup&nbsp;dan&nbsp;deliverables&nbsp;pengadaan&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;sesuai&nbsp;dengan&nbsp;Kontrak&nbsp;Perjanjian&nbsp;Kerja&nbsp;Sama&nbsp;Nomor:&nbsp;<strong>Tel.23/LG&nbsp;270/JDPT-0203000/2026</strong></li><li><strong>PIHAK&nbsp;PERTAMA</strong>&nbsp;menyatakan&nbsp;telah&nbsp;memeriksa&nbsp;hasil&nbsp;pekerjaan&nbsp;dan&nbsp;deliverables&nbsp;dimaksud&nbsp;pada&nbsp;butir&nbsp;1&nbsp;dengan&nbsp;hasil&nbsp;Baik&nbsp;dan&nbsp;Sesuai.</li><li>Laporan&nbsp;hasil&nbsp;dan/atau&nbsp;checklist&nbsp;penyelesaian&nbsp;pekerjaan&nbsp;sebagaimana&nbsp;terlampir.</li></ol><p>Demikian&nbsp;Berita&nbsp;Acara&nbsp;Penyelesaian&nbsp;Pekerjaan&nbsp;(BAPP)&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;ini&nbsp;dibuat&nbsp;dalam&nbsp;rangkap&nbsp;2&nbsp;(dua)&nbsp;asli,&nbsp;masing-masing&nbsp;sama&nbsp;bunyinya&nbsp;serta&nbsp;mempunyai&nbsp;kekuatan&nbsp;hukum&nbsp;yang&nbsp;sama&nbsp;setelah&nbsp;ditandatangani&nbsp;kedua&nbsp;belah&nbsp;pihak&nbsp;untuk&nbsp;dipergunakan&nbsp;sebagaimana&nbsp;mestinya.</p>', '2026-09-07 00:00:00', 'M.Arief Widhiyanto', 'SM HCM & Logistic', 'Nava Gia Ginasta, M.Kom', 'Direktur Utama', '<p>Berdasarkan:</p><ol><li>Kontrak&nbsp;Perjanjian&nbsp;Kerja&nbsp;Sama&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;Nomor:&nbsp;<strong>Tel.23/LG&nbsp;270/JDPT-0203000/2026</strong>&nbsp;tanggal&nbsp;<strong>11&nbsp;Mei&nbsp;2026</strong></li><li>Amandemen&nbsp;Kesatu&nbsp;Kontrak&nbsp;Perjanjian&nbsp;Kerja&nbsp;Sama&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;Nomor:&nbsp;<strong>Tel.23/LG&nbsp;270/JDPT-0203000/2026</strong>&nbsp;tanggal&nbsp;<strong>11&nbsp;Mei&nbsp;2026</strong></li><li>Berita&nbsp;Acara&nbsp;Penyelesaian&nbsp;Pekerjaan&nbsp;(BAPP)&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;Nomor:&nbsp;<strong>Tel.23/LG&nbsp;270/JDPT-0203000/2026</strong>&nbsp;tanggal&nbsp;<strong>11&nbsp;Mei&nbsp;2026</strong></li></ol><p>Dengan&nbsp;ini&nbsp;menyatakan&nbsp;bahwa:</p><ol><li>1.&nbsp;&nbsp;&nbsp;&nbsp;<strong>PIHAK&nbsp;KEDUA</strong>&nbsp;menyerahkan&nbsp;seluruh&nbsp;hasil&nbsp;pekerjaan&nbsp;dan&nbsp;deliverables&nbsp;sesuai&nbsp;dengan&nbsp;dokumen&nbsp;tersebut&nbsp;di&nbsp;atas&nbsp;kepada&nbsp;<strong>PIHAK&nbsp;PERTAMA</strong>.</li><li>2.&nbsp;&nbsp;&nbsp;&nbsp;<strong>PIHAK&nbsp;PERTAMA</strong>&nbsp;menerima&nbsp;seluruh&nbsp;hasil&nbsp;pekerjaan&nbsp;dan&nbsp;deliverables&nbsp;sesuai&nbsp;sesuai&nbsp;dengan&nbsp;dokumen&nbsp;tersebut&nbsp;di&nbsp;atas&nbsp;dari&nbsp;<strong>PIHAK&nbsp;KEDUA</strong>.</li></ol><p>Demikian&nbsp;Berita&nbsp;Acara&nbsp;Serah&nbsp;Terima&nbsp;Pekerjaan&nbsp;(BAST)&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;ini&nbsp;dibuat&nbsp;dalam&nbsp;rangkap&nbsp;2&nbsp;(dua)&nbsp;asli,&nbsp;masing-masing&nbsp;sama&nbsp;bunyinya&nbsp;serta&nbsp;mempunyai&nbsp;kekuatan&nbsp;hukum&nbsp;yang&nbsp;sama&nbsp;setelah&nbsp;ditandatangani&nbsp;kedua&nbsp;belah&nbsp;pihak&nbsp;untuk&nbsp;dipergunakan&nbsp;sebagaimana&nbsp;mestinya.</p>', '2026-09-08 10:49:33', '2026-09-08 10:50:01', 'Dana Pensiun Telkom', 'PT Crop Inspirasi Digital', 0, 0, NULL);
INSERT INTO `project_documents` (`id`, `project_id`, `location`, `inspection_date`, `inspection_officer_name_1`, `inspection_officer_role_1`, `inspection_officer_name_2`, `inspection_officer_role_2`, `inspection_description`, `progress_date`, `progress_officer_name_1`, `progress_officer_role_1`, `progress_officer_name_2`, `progress_officer_role_2`, `progress_description`, `handover_date`, `handover_officer_name_1`, `handover_officer_role_1`, `handover_officer_name_2`, `handover_officer_role_2`, `handover_description`, `created_at`, `updated_at`, `company_1`, `company_2`, `progress_status`, `handover_status`, `bapp_attachment`) VALUES (5, 1, 'Dana Pensiun Telkom', '2026-10-30 00:00:00', 'Angkoso Suryocahyono', 'PGS VP Information System & Report', 'Nava Gia Ginasta, M.Kom', 'Direktur Utama', '<p style="text-align: justify;">Bahwa&nbsp;<strong>PIHAK&nbsp;KEDUA&nbsp;</strong>telah&nbsp;menyelesaikan&nbsp;pekerjaan&nbsp;<em>Support&nbsp;</em>Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom&nbsp;2026&nbsp;yang&nbsp;sesuai&nbsp;dengan&nbsp;Kontrak&nbsp;nomor:&nbsp;121/HK-71/Dapentel-020/2026&nbsp;periode&nbsp;September&nbsp;2026&nbsp;yang&nbsp;telah&nbsp;sesuai&nbsp;dengan&nbsp;TOR&nbsp;dengan&nbsp;detail&nbsp;sebagai&nbsp;berikut:</p><ol><li>Support&nbsp;Pengembangan&nbsp;Aplikasi.</li><li>Support&nbsp;Pemeliharaan&nbsp;Aplikasi.</li></ol><p style="text-align: justify;">Detil&nbsp;dari&nbsp;pekerjaan&nbsp;tersebut&nbsp;terlampir&nbsp;pada&nbsp;Dokumen&nbsp;Laporan&nbsp;Pekerjaan&nbsp;atau&nbsp;dapat&nbsp;diakses&nbsp;melalui&nbsp;link&nbsp;<a href="https://bit.ly/DapenCrop2026" rel="noopener noreferrer" target="_blank" style="color: black;">https://bit.ly/DapenCrop2026</a>.</p><p style="text-align: justify;"><strong>PIHAK&nbsp;PERTAMA&nbsp;</strong>telah&nbsp;menerima&nbsp;hasil&nbsp;pelaksanaan&nbsp;pekerjaan&nbsp;berupa&nbsp;lampiran&nbsp;tersebut&nbsp;diatas&nbsp;hasil&nbsp;dari&nbsp;<em>Support&nbsp;</em>Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom&nbsp;2026&nbsp;yang&nbsp;sesuai&nbsp;dengan&nbsp;Kontrak&nbsp;nomor:&nbsp;121/HK-71/Dapentel-020/2026&nbsp;periode&nbsp;Oktober&nbsp;2026.</p><p style="text-align: justify;"></p><p style="text-align: justify;">Demikian&nbsp;berita&nbsp;acara&nbsp;pekerjaan&nbsp;(BAP)&nbsp;ini&nbsp;dibuat&nbsp;untuk&nbsp;dipergunakan&nbsp;sebagaimana&nbsp;mestinya.</p>', '2026-10-04 00:00:00', 'Angkoso Suryocahyono', 'PGS VP Information System & Reporting', 'Nava Gia Ginasta, M.Kom', 'Direktur Utama', '<p>Berdasarkan&nbsp;Kontrak&nbsp;Perjanjian&nbsp;Kerja&nbsp;Sama&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;Nomor:&nbsp;<strong>Tel.23/LG&nbsp;270/JDPT-0203000/2026</strong>&nbsp;tanggal&nbsp;<strong>11&nbsp;Mei&nbsp;2026</strong></p><p>Dengan&nbsp;ini&nbsp;menerangkan&nbsp;bahwa:</p><ol><li><strong>PIHAK&nbsp;KEDUA</strong>&nbsp;menyatakan&nbsp;telah&nbsp;menyelesaikan&nbsp;pekerjaan&nbsp;sesuai&nbsp;ruang&nbsp;lingkup&nbsp;dan&nbsp;deliverables&nbsp;pengadaan&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;sesuai&nbsp;dengan&nbsp;Kontrak&nbsp;Perjanjian&nbsp;Kerja&nbsp;Sama&nbsp;Nomor:&nbsp;<strong>Tel.23/LG&nbsp;270/JDPT-0203000/2026</strong></li><li><strong>PIHAK&nbsp;PERTAMA</strong>&nbsp;menyatakan&nbsp;telah&nbsp;memeriksa&nbsp;hasil&nbsp;pekerjaan&nbsp;dan&nbsp;deliverables&nbsp;dimaksud&nbsp;pada&nbsp;butir&nbsp;1&nbsp;dengan&nbsp;hasil&nbsp;Baik&nbsp;dan&nbsp;Sesuai.</li><li>Laporan&nbsp;hasil&nbsp;dan/atau&nbsp;checklist&nbsp;penyelesaian&nbsp;pekerjaan&nbsp;sebagaimana&nbsp;terlampir.</li></ol><p>Demikian&nbsp;Berita&nbsp;Acara&nbsp;Penyelesaian&nbsp;Pekerjaan&nbsp;(BAPP)&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;ini&nbsp;dibuat&nbsp;dalam&nbsp;rangkap&nbsp;2&nbsp;(dua)&nbsp;asli,&nbsp;masing-masing&nbsp;sama&nbsp;bunyinya&nbsp;serta&nbsp;mempunyai&nbsp;kekuatan&nbsp;hukum&nbsp;yang&nbsp;sama&nbsp;setelah&nbsp;ditandatangani&nbsp;kedua&nbsp;belah&nbsp;pihak&nbsp;untuk&nbsp;dipergunakan&nbsp;sebagaimana&nbsp;mestinya.</p>', '2026-10-04 00:00:00', 'M.Arief Widhiyanto', 'SM HCM & Logistic', 'Nava Gia Ginasta, M.Kom', 'Direktur Utama', '<p>Berdasarkan:</p><ol><li>Kontrak&nbsp;Perjanjian&nbsp;Kerja&nbsp;Sama&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;Nomor:&nbsp;<strong>Tel.23/LG&nbsp;270/JDPT-0203000/2026</strong>&nbsp;tanggal&nbsp;<strong>11&nbsp;Mei&nbsp;2026</strong></li><li>Amandemen&nbsp;Kesatu&nbsp;Kontrak&nbsp;Perjanjian&nbsp;Kerja&nbsp;Sama&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;Nomor:&nbsp;<strong>Tel.23/LG&nbsp;270/JDPT-0203000/2026</strong>&nbsp;tanggal&nbsp;<strong>11&nbsp;Mei&nbsp;2026</strong></li><li>Berita&nbsp;Acara&nbsp;Penyelesaian&nbsp;Pekerjaan&nbsp;(BAPP)&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;Nomor:&nbsp;<strong>Tel.23/LG&nbsp;270/JDPT-0203000/2026</strong>&nbsp;tanggal&nbsp;<strong>11&nbsp;Mei&nbsp;2026</strong></li></ol><p>Dengan&nbsp;ini&nbsp;menyatakan&nbsp;bahwa:</p><ol><li>1.&nbsp;&nbsp;&nbsp;&nbsp;<strong>PIHAK&nbsp;KEDUA</strong>&nbsp;menyerahkan&nbsp;seluruh&nbsp;hasil&nbsp;pekerjaan&nbsp;dan&nbsp;deliverables&nbsp;sesuai&nbsp;dengan&nbsp;dokumen&nbsp;tersebut&nbsp;di&nbsp;atas&nbsp;kepada&nbsp;<strong>PIHAK&nbsp;PERTAMA</strong>.</li><li>2.&nbsp;&nbsp;&nbsp;&nbsp;<strong>PIHAK&nbsp;PERTAMA</strong>&nbsp;menerima&nbsp;seluruh&nbsp;hasil&nbsp;pekerjaan&nbsp;dan&nbsp;deliverables&nbsp;sesuai&nbsp;sesuai&nbsp;dengan&nbsp;dokumen&nbsp;tersebut&nbsp;di&nbsp;atas&nbsp;dari&nbsp;<strong>PIHAK&nbsp;KEDUA</strong>.</li></ol><p>Demikian&nbsp;Berita&nbsp;Acara&nbsp;Serah&nbsp;Terima&nbsp;Pekerjaan&nbsp;(BAST)&nbsp;<strong>Support&nbsp;Pengembangan&nbsp;&amp;&nbsp;Pemeliharaan&nbsp;Aplikasi&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;ini&nbsp;dibuat&nbsp;dalam&nbsp;rangkap&nbsp;2&nbsp;(dua)&nbsp;asli,&nbsp;masing-masing&nbsp;sama&nbsp;bunyinya&nbsp;serta&nbsp;mempunyai&nbsp;kekuatan&nbsp;hukum&nbsp;yang&nbsp;sama&nbsp;setelah&nbsp;ditandatangani&nbsp;kedua&nbsp;belah&nbsp;pihak&nbsp;untuk&nbsp;dipergunakan&nbsp;sebagaimana&nbsp;mestinya.</p>', '2026-10-12 10:56:04', '2026-10-28 08:29:57', 'Dana Pensiun Telkom', 'PT Crop Inspirasi Digital', 0, 0, NULL);
INSERT INTO `project_documents` (`id`, `project_id`, `location`, `inspection_date`, `inspection_officer_name_1`, `inspection_officer_role_1`, `inspection_officer_name_2`, `inspection_officer_role_2`, `inspection_description`, `progress_date`, `progress_officer_name_1`, `progress_officer_role_1`, `progress_officer_name_2`, `progress_officer_role_2`, `progress_description`, `handover_date`, `handover_officer_name_1`, `handover_officer_role_1`, `handover_officer_name_2`, `handover_officer_role_2`, `handover_description`, `created_at`, `updated_at`, `company_1`, `company_2`, `progress_status`, `handover_status`, `bapp_attachment`) VALUES (6, 2, 'Dana Pensiun Telkom', '2026-11-17 00:00:00', 'Angkoso Suryocahyono', 'PGS VP Information System & Report', 'Nava Gia Ginasta', 'Direktur Utama', '<p style="text-align: justify;">Bahwa&nbsp;<strong>PIHAK&nbsp;KEDUA</strong>&nbsp;telah&nbsp;menyelesaikan&nbsp;pekerjaan&nbsp;Jasa&nbsp;Peningkatan&nbsp;Keamanan&nbsp;Siber&nbsp;untuk&nbsp;Public&nbsp;Web&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom&nbsp;yang&nbsp;sesuai&nbsp;dengan&nbsp;Nota&nbsp;Pesanan&nbsp;nomor:&nbsp;1424/LG-29/Dapentel-012/2026&nbsp;dan&nbsp;telah&nbsp;dilaksanakan&nbsp;sesuai&nbsp;dengan&nbsp;TOR&nbsp;dengan&nbsp;detail&nbsp;sebagai&nbsp;berikut:</p><ol><li>&nbsp;Laporan&nbsp;Penanganan&nbsp;Ancaman&nbsp;Zero-Day&nbsp;PHP2Shell;</li><li>&nbsp;Laporan&nbsp;Perbaikan&nbsp;Vulnerability&nbsp;Assessment&nbsp;(VA)&nbsp;Cyber&nbsp;Security&nbsp;Telkom&nbsp;2026;</li><li>&nbsp;Laporan&nbsp;Pemasangan&nbsp;Konfigurasi&nbsp;Frame&nbsp;Continuous&nbsp;Integration/Continuous&nbsp;Delivery&nbsp;(CI/CD);</li><li>&nbsp;Laporan&nbsp;Migrasi&nbsp;Public&nbsp;Web&nbsp;ke&nbsp;Data&nbsp;Center&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom.</li></ol><p style="text-align: justify;">Detil&nbsp;dari&nbsp;pekerjaan&nbsp;tersebut&nbsp;terlampir&nbsp;pada&nbsp;link&nbsp;<a href="https://bit.ly/DokumenPeningkatanSiberDapenTelkom2026" rel="noopener noreferrer" target="_blank" style="color: black;">&nbsp;https://bit.ly/DokumenPeningkatanSiberDapenTelkom2026</a>.</p><p style="text-align: justify;"><strong>PIHAK&nbsp;PERTAMA</strong>&nbsp;telah&nbsp;menerima&nbsp;hasil&nbsp;pelaksanaan&nbsp;pekerjaan&nbsp;berupa&nbsp;lampiran&nbsp;tersebut&nbsp;diatas&nbsp;hasil&nbsp;dari&nbsp;Jasa&nbsp;Peningkatan&nbsp;Keamanan&nbsp;Siber&nbsp;untuk&nbsp;Public&nbsp;Web&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom&nbsp;2026&nbsp;yang&nbsp;sesuai&nbsp;dengan&nbsp;Nota&nbsp;Pesanan&nbsp;nomor:&nbsp;1424/LG-29/Dapentel-012/2026.</p><p style="text-align: justify;"></p><p style="text-align: justify;">Demikian&nbsp;berita&nbsp;acara&nbsp;pekerjaan&nbsp;(BAP)&nbsp;ini&nbsp;dibuat&nbsp;untuk&nbsp;dipergunakan&nbsp;sebagaimana&nbsp;mestinya.</p>', '2026-11-18 00:00:00', 'Angkoso Suryocahyono', 'PGS VP Information System & Report', 'Nava Gia Ginasta', 'Direktur Utama', '<p>Berdasarkan&nbsp;Kontrak&nbsp;Perjanjian&nbsp;Kerja&nbsp;Sama&nbsp;Jasa&nbsp;Peningkatan&nbsp;Keamanan&nbsp;Siber&nbsp;untuk&nbsp;Public&nbsp;Web&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom&nbsp;Nota&nbsp;Pesanan&nbsp;nomor:&nbsp;1424/LG-29/Dapentel-012/2026&nbsp;tanggal&nbsp;30&nbsp;Oktober&nbsp;2026,&nbsp;Dengan&nbsp;ini&nbsp;menerangkan&nbsp;bahwa:</p><ol><li><strong>PIHAK&nbsp;KEDUA</strong>&nbsp;menyatakan&nbsp;telah&nbsp;menyelesaikan&nbsp;pekerjaan&nbsp;sesuai&nbsp;ruang&nbsp;lingkup&nbsp;dan&nbsp;<em>deliverables</em>&nbsp;pengadaan&nbsp;Jasa&nbsp;Peningkatan&nbsp;Keamanan&nbsp;Siber&nbsp;untuk&nbsp;Public&nbsp;Web&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom&nbsp;sesuai&nbsp;dengan&nbsp;Nota&nbsp;Pesanan&nbsp;nomor:&nbsp;1424/LG-29/Dapentel-012/2026;</li><li><strong>PIHAK&nbsp;PERTAMA</strong>&nbsp;menyatakan&nbsp;telah&nbsp;memeriksa&nbsp;hasil&nbsp;pekerjaan&nbsp;dan&nbsp;<em>deliverables</em>&nbsp;dimaksud&nbsp;pada&nbsp;butir&nbsp;1&nbsp;dengan&nbsp;hasil&nbsp;Baik&nbsp;dan&nbsp;Sesuai;</li><li>Laporan&nbsp;hasil&nbsp;dan/atau&nbsp;checklist&nbsp;penyelesaian&nbsp;pekerjaan&nbsp;sebagaimana&nbsp;pada&nbsp;link&nbsp;<a href="https://bit.ly/DokumenPeningkatanSiberDapenTelkom2026" rel="noopener noreferrer" target="_blank" style="color: black;">&nbsp;https://bit.ly/DokumenPeningkatanSiberDapenTelkom2026</a>.</li></ol><p>Demikian&nbsp;Berita&nbsp;Acara&nbsp;Penyelesaian&nbsp;Pekerjaan&nbsp;(BAPP)&nbsp;Jasa&nbsp;Peningkatan&nbsp;Keamanan&nbsp;Siber&nbsp;untuk&nbsp;Public&nbsp;Web&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom&nbsp;ini&nbsp;dibuat&nbsp;dalam&nbsp;rangkap&nbsp;2&nbsp;(dua)&nbsp;asli,&nbsp;masing-masing&nbsp;sama&nbsp;bunyinya&nbsp;serta&nbsp;mempunyai&nbsp;kekuatan&nbsp;hukum&nbsp;yang&nbsp;sama&nbsp;setelah&nbsp;ditandatangani&nbsp;kedua&nbsp;belah&nbsp;pihak&nbsp;untuk&nbsp;dipergunakan&nbsp;sebagaimana&nbsp;mestinya.</p>', '2026-11-18 00:00:00', 'Angkoso Suryocahyono', 'PGS VP Information System & Report', 'Nava Gia Ginasta', 'Direktur Utama', '<p>Berdasarkan:</p><ol><li>Nota&nbsp;Pesanan&nbsp;Jasa&nbsp;Peningkatan&nbsp;Keamanan&nbsp;Siber&nbsp;untuk&nbsp;Public&nbsp;Web&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom&nbsp;nomor:&nbsp;1424/LG-29/Dapentel-012/2026;&nbsp;dan</li><li>Berita&nbsp;Acara&nbsp;Penyelesaian&nbsp;Pekerjaan&nbsp;(BAPP)&nbsp;Jasa&nbsp;Peningkatan&nbsp;Keamanan&nbsp;Siber&nbsp;untuk&nbsp;Public&nbsp;Web&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom&nbsp;tanggal&nbsp;16&nbsp;November&nbsp;2026.</li></ol><p>Dengan&nbsp;ini&nbsp;menyatakan&nbsp;bahwa:</p><p>1.&nbsp;&nbsp;&nbsp;&nbsp;<strong>PIHAK&nbsp;KEDUA</strong>&nbsp;menyerahkan&nbsp;seluruh&nbsp;hasil&nbsp;pekerjaan&nbsp;dan&nbsp;<em>deliverables</em>&nbsp;sesuai&nbsp;dengan&nbsp;dokumen&nbsp;tersebut&nbsp;di&nbsp;atas&nbsp;kepada&nbsp;<strong>PIHAK&nbsp;PERTAMA</strong>.</p><p>2.&nbsp;&nbsp;&nbsp;&nbsp;<strong>PIHAK&nbsp;PERTAMA</strong>&nbsp;menerima&nbsp;seluruh&nbsp;hasil&nbsp;pekerjaan&nbsp;dan&nbsp;<em>deliverables</em>&nbsp;sesuai&nbsp;sesuai&nbsp;dengan&nbsp;dokumen&nbsp;tersebut&nbsp;di&nbsp;atas&nbsp;dari&nbsp;<strong>PIHAK&nbsp;KEDUA</strong>.</p><p></p><p>Demikian&nbsp;Berita&nbsp;Acara&nbsp;Serah&nbsp;Terima&nbsp;Pekerjaan&nbsp;(BAST)&nbsp;<strong>Jasa&nbsp;Peningkatan&nbsp;Keamanan&nbsp;Siber&nbsp;untuk&nbsp;Public&nbsp;Web&nbsp;Dana&nbsp;Pensiun&nbsp;Telkom</strong>&nbsp;ini&nbsp;dibuat&nbsp;dalam&nbsp;rangkap&nbsp;2&nbsp;(dua)&nbsp;asli,&nbsp;masing-masing&nbsp;sama&nbsp;bunyinya&nbsp;serta&nbsp;mempunyai&nbsp;kekuatan&nbsp;hukum&nbsp;yang&nbsp;sama&nbsp;setelah&nbsp;ditandatangani&nbsp;kedua&nbsp;belah&nbsp;pihak&nbsp;untuk&nbsp;dipergunakan&nbsp;sebagaimana&nbsp;mestinya.</p>', '2026-11-05 11:11:08', '2026-11-15 20:52:39', 'Dana Pensiun Telkom', 'PT Crop Inspirasi Digital', 1, 1, NULL);

DROP TABLE IF EXISTS `qr_code_histories`;
CREATE TABLE `qr_code_histories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `qr_code_id` int(11) NOT NULL,
  `action` varchar(20) NOT NULL,
  `title` varchar(150) NOT NULL,
  `qr_text` text NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `size` int(11) NOT NULL,
  `level` varchar(1) NOT NULL,
  `changed_by` int(11) DEFAULT NULL,
  `changed_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (1, 1, 'create', 'QR Uji', 'TEST-123', NULL, 325, 'H', 1, '2026-11-21 07:44:42');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (2, 1, 'update', 'QR Uji', 'TEST-123', NULL, 325, 'H', 1, '2026-11-21 07:44:43');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (3, 1, 'delete', 'QR Uji Edit', 'TEST-456', NULL, 390, 'H', 1, '2026-11-21 07:44:43');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (4, 2, 'create', 'Qrcode', 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.891.892,00#7.358.108,00#0,00#APPROVED', NULL, 325, 'M', 2, '2026-11-21 07:46:07');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (5, 3, 'create', 'QR E2E', 'E2E-TEST', NULL, 325, 'M', 1, '2026-11-21 07:46:23');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (6, 3, 'update', 'QR E2E', 'E2E-TEST', NULL, 325, 'M', 1, '2026-11-21 07:46:26');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (7, 3, 'delete', 'QR E2E', 'E2E-TEST', '1795243586317_965ecc7a.png', 325, 'H', 1, '2026-11-21 07:46:28');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (8, 4, 'create', 'NO-TITLE-TEST', 'NO-TITLE-TEST', NULL, 325, 'M', 1, '2026-11-21 07:52:37');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (9, 4, 'update', 'NO-TITLE-TEST', 'NO-TITLE-TEST', NULL, 325, 'M', 1, '2026-11-21 07:52:40');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (10, 4, 'delete', 'NO-TITLE-EDIT', 'NO-TITLE-EDIT', NULL, 325, 'M', 1, '2026-11-21 07:52:41');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (11, 5, 'create', 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.', 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.891.892,00#7.358.108,00#0,00#APPROVED', '1795244016274_e91c0bb9.jpg', 325, 'H', 2, '2026-11-21 07:53:36');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (12, 5, 'update', 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.', 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.891.892,00#7.358.108,00#0,00#APPROVED', '1795244016274_e91c0bb9.jpg', 325, 'H', 2, '2026-11-21 07:53:57');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (13, 5, 'update', 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.', 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.891.892,00#7.358.108,00#0,00#APPROVED', '1795244016274_e91c0bb9.jpg', 325, 'H', 2, '2026-11-21 07:53:58');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (14, 6, 'create', 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.', 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.891.892,00#7.358.108,00#0,00#APPROVED', '1795244050321_d9851e7c.jpg', 325, 'H', 2, '2026-11-21 07:54:10');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (15, 6, 'update', 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.', 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.891.892,00#7.358.108,00#0,00#APPROVED', '1795244050321_d9851e7c.jpg', 325, 'H', 2, '2026-11-21 07:54:19');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (16, 6, 'delete', 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.', 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.891.892,00#7.358.108,00#0,00#APPROVED', '1795244050321_d9851e7c.jpg', 325, 'H', 2, '2026-11-21 07:54:38');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (17, 5, 'delete', 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.', 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.891.892,00#7.358.108,00#0,00#APPROVED', '1795244016274_e91c0bb9.jpg', 325, 'H', 2, '2026-11-21 07:54:44');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (18, 7, 'create', 'IMAGE-TEST', 'IMAGE-TEST', '1795244129975_447a88f6.png', 325, 'H', 1, '2026-11-21 07:55:29');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (19, 7, 'delete', 'IMAGE-TEST', 'IMAGE-TEST', '1795244129975_447a88f6.png', 325, 'H', 1, '2026-11-21 07:55:33');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (20, 8, 'create', 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.', 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.891.892,00#7.358.108,00#0,00#APPROVED', '1795244191977_139bd577.jpg', 325, 'H', 2, '2026-11-21 07:56:31');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (21, 8, 'delete', 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.', 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.891.892,00#7.358.108,00#0,00#APPROVED', '1795244191977_139bd577.jpg', 325, 'H', 2, '2026-11-21 10:15:56');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (22, 2, 'delete', 'Qrcode', 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.891.892,00#7.358.108,00#0,00#APPROVED', NULL, 325, 'M', 2, '2026-11-21 10:15:58');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (23, 9, 'create', 'j', 'j', '1795252566522_3a715cce.jpeg', 325, 'H', 2, '2026-11-21 10:16:06');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (24, 9, 'delete', 'j', 'j', '1795252566522_3a715cce.jpeg', 325, 'H', 2, '2026-11-21 10:16:10');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (25, 10, 'create', 'https://example.com/test', 'https://example.com/test', NULL, 325, 'M', 1, '2026-11-22 07:38:56');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (26, 10, 'update', 'https://example.com/test', 'https://example.com/test', NULL, 325, 'M', 1, '2026-11-22 07:38:56');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (27, 10, 'delete', 'https://example.com/updated', 'https://example.com/updated', NULL, 300, 'H', 1, '2026-11-22 07:38:56');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (28, 11, 'create', 'image test', 'image test', '1795307940983.png', 325, 'H', 1, '2026-11-22 07:39:00');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (29, 11, 'update', 'image test', 'image test', '1795307940983.png', 325, 'H', 1, '2026-11-22 07:39:00');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (30, 11, 'delete', 'image test', 'image test', NULL, 325, 'H', 1, '2026-11-22 07:39:01');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (31, 12, 'create', 'navagia@ulbi.ac.id', 'navagia@ulbi.ac.id', '1795307958667.JPEG', 325, 'H', 2, '2026-11-22 07:39:18');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (32, 13, 'create', 'mm', 'mm', NULL, 325, 'M', 2, '2026-11-22 08:54:06');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (33, 13, 'delete', 'mm', 'mm', NULL, 325, 'M', 2, '2026-11-22 08:54:10');
INSERT INTO `qr_code_histories` (`id`, `qr_code_id`, `action`, `title`, `qr_text`, `image`, `size`, `level`, `changed_by`, `changed_at`) VALUES (34, 12, 'delete', 'navagia@ulbi.ac.id', 'navagia@ulbi.ac.id', '1795307958667.JPEG', 325, 'H', 2, '2026-11-22 08:54:12');

DROP TABLE IF EXISTS `qr_codes`;
CREATE TABLE `qr_codes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `qr_text` text NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `size` int(11) NOT NULL DEFAULT '320',
  `level` varchar(1) NOT NULL DEFAULT 'M',
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO `qr_codes` (`id`, `title`, `qr_text`, `image`, `size`, `level`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES (1, 'QR Uji Edit', 'TEST-456', NULL, 390, 'H', 1, 1, '2026-11-21 07:44:42', '2026-11-21 07:44:43', '2026-11-21 07:44:43');
INSERT INTO `qr_codes` (`id`, `title`, `qr_text`, `image`, `size`, `level`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES (2, 'Qrcode', 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.891.892,00#7.358.108,00#0,00#APPROVED', NULL, 325, 'M', 2, 2, '2026-11-21 07:46:07', '2026-11-21 10:15:58', '2026-11-21 10:15:58');
INSERT INTO `qr_codes` (`id`, `title`, `qr_text`, `image`, `size`, `level`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES (3, 'QR E2E', 'E2E-TEST', '1795243586317_965ecc7a.png', 325, 'H', 1, 1, '2026-11-21 07:46:23', '2026-11-21 07:46:28', '2026-11-21 07:46:28');
INSERT INTO `qr_codes` (`id`, `title`, `qr_text`, `image`, `size`, `level`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES (4, 'NO-TITLE-EDIT', 'NO-TITLE-EDIT', NULL, 325, 'M', 1, 1, '2026-11-21 07:52:37', '2026-11-21 07:52:41', '2026-11-21 07:52:41');
INSERT INTO `qr_codes` (`id`, `title`, `qr_text`, `image`, `size`, `level`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES (5, 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.', 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.891.892,00#7.358.108,00#0,00#APPROVED', '1795244016274_e91c0bb9.jpg', 325, 'H', 2, 2, '2026-11-21 07:53:36', '2026-11-21 07:54:44', '2026-11-21 07:54:44');
INSERT INTO `qr_codes` (`id`, `title`, `qr_text`, `image`, `size`, `level`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES (6, 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.', 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.891.892,00#7.358.108,00#0,00#APPROVED', '1795244050321_d9851e7c.jpg', 325, 'H', 2, 2, '2026-11-21 07:54:10', '2026-11-21 07:54:38', '2026-11-21 07:54:38');
INSERT INTO `qr_codes` (`id`, `title`, `qr_text`, `image`, `size`, `level`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES (7, 'IMAGE-TEST', 'IMAGE-TEST', '1795244129975_447a88f6.png', 325, 'H', 1, 1, '2026-11-21 07:55:29', '2026-11-21 07:55:33', '2026-11-21 07:55:33');
INSERT INTO `qr_codes` (`id`, `title`, `qr_text`, `image`, `size`, `level`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES (8, 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.', 'CROP INSPIRASI D#0963257928423000#DANA PENSIUN TEL#0012809034423000#04012500299971365#16-11-2026#66.891.892,00#7.358.108,00#0,00#APPROVED', '1795244191977_139bd577.jpg', 325, 'H', 2, 2, '2026-11-21 07:56:31', '2026-11-21 10:15:56', '2026-11-21 10:15:56');
INSERT INTO `qr_codes` (`id`, `title`, `qr_text`, `image`, `size`, `level`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES (9, 'j', 'j', '1795252566522_3a715cce.jpeg', 325, 'H', 2, 2, '2026-11-21 10:16:06', '2026-11-21 10:16:10', '2026-11-21 10:16:10');
INSERT INTO `qr_codes` (`id`, `title`, `qr_text`, `image`, `size`, `level`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES (10, 'https://example.com/updated', 'https://example.com/updated', NULL, 300, 'H', 1, 1, '2026-11-22 07:38:56', '2026-11-22 07:38:56', '2026-11-22 07:38:56');
INSERT INTO `qr_codes` (`id`, `title`, `qr_text`, `image`, `size`, `level`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES (11, 'image test', 'image test', NULL, 325, 'H', 1, 1, '2026-11-22 07:39:00', '2026-11-22 07:39:01', '2026-11-22 07:39:01');
INSERT INTO `qr_codes` (`id`, `title`, `qr_text`, `image`, `size`, `level`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES (12, 'navagia@ulbi.ac.id', 'navagia@ulbi.ac.id', '1795307958667.JPEG', 325, 'H', 2, 2, '2026-11-22 07:39:18', '2026-11-22 08:54:12', '2026-11-22 08:54:12');
INSERT INTO `qr_codes` (`id`, `title`, `qr_text`, `image`, `size`, `level`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES (13, 'mm', 'mm', NULL, 325, 'M', 2, 2, '2026-11-22 08:54:06', '2026-11-22 08:54:10', '2026-11-22 08:54:10');

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `name_role` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `lock` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `roles` (`role_id`, `name_role`, `description`, `lock`) VALUES (1, 'Super User', 'User dengan Otoritas Penuh', 1);
INSERT INTO `roles` (`role_id`, `name_role`, `description`, `lock`) VALUES (7, 'Admin', NULL, 0);
INSERT INTO `roles` (`role_id`, `name_role`, `description`, `lock`) VALUES (8, 'Direktur', 'Melihat seluruh laporan keuangan dan menyetujui transaksi', 0);
INSERT INTO `roles` (`role_id`, `name_role`, `description`, `lock`) VALUES (9, 'Finance Manager', 'Mengelola keuangan dan persetujuan', 0);
INSERT INTO `roles` (`role_id`, `name_role`, `description`, `lock`) VALUES (10, 'Finance Staff', 'Input dan mengelola transaksi keuangan', 0);
INSERT INTO `roles` (`role_id`, `name_role`, `description`, `lock`) VALUES (11, 'HR', 'Mengelola data karyawan dan penggajian', 0);
INSERT INTO `roles` (`role_id`, `name_role`, `description`, `lock`) VALUES (12, 'Auditor', 'Akses baca laporan dan riwayat transaksi', 0);

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `users` (`id`, `email`, `password`, `name`, `role_id`) VALUES (1, 'admin@test.com', '$2b$10$soFiaO5KQUTm/58cgSTWruG67d6AIukPLAILDE6zdD9Eh95a71bUG', 'Super Admin', 7);
INSERT INTO `users` (`id`, `email`, `password`, `name`, `role_id`) VALUES (2, 'navagia@ulbi.ac.id', '$2b$10$5bCoiRNi5KLz031r6tsDsuHfIpvUsb5mjhACuVQKoq3L3rNgLWrWC', 'Nava Gia Ginasta', 1);
INSERT INTO `users` (`id`, `email`, `password`, `name`, `role_id`) VALUES (3, 'jaya@gmail.com', '$2b$10$hO5mHY3otZvxv9O8EOrX7.h13p4ixOBSlY973d/hFqfrqXTOCjpq.', 'Jaya', 1);

SET FOREIGN_KEY_CHECKS = 1;
