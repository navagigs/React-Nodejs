<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'cropcoi2_adm');
define('DB_PASS', 'cropcoi2_adm');
define('DB_NAME', 'cropcoi2_adm');
define('APP_URL', 'http://adm.crop.co.id/');
define('JWT_SECRET', '8918eb68aac06f5a18b09eab66923fe6ffa34948db72351a84af658354e97ae3');
